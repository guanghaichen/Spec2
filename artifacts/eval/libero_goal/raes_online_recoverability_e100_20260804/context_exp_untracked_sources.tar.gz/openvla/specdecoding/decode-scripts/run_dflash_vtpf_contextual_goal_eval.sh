#!/usr/bin/env bash
set -euo pipefail

# VTPF + observation-conditioned recoverability allocation.
#
# Every target cycle keeps the first held action. A nonparametric risk memory
# and an online dual budget decide whether the second inverse-age hold is spent
# in the current visual/state/action context. No periodic target schedule is
# replayed, and the original VTPF/DFlash fallback remains unchanged.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "${SPEC_CKPT:-}" ]]; then
  echo "请显式设置 SPEC_CKPT=/absolute/path/to/checkpoint。" >&2
  exit 1
fi
if [[ -z "${DFLASH_CONTEXT_RISK_PROFILE:-}" ]]; then
  echo "请显式设置 DFLASH_CONTEXT_RISK_PROFILE=/absolute/path/to/context_risk_profile.json。" >&2
  exit 1
fi
if [[ ! -f "${DFLASH_CONTEXT_RISK_PROFILE}" ]]; then
  echo "上下文风险 profile 不存在: ${DFLASH_CONTEXT_RISK_PROFILE}" >&2
  exit 1
fi

export DFLASH_TEMPORAL_HOLD_POLICY_OVERRIDE=True
export DFLASH_TEMPORAL_HOLD_POLICY=contextual_budget
export DFLASH_CONTEXT_TARGET_DENSITY="${DFLASH_CONTEXT_TARGET_DENSITY:-0.4032258064516129}"
export DFLASH_CONTEXT_ONLINE_UPDATE="${DFLASH_CONTEXT_ONLINE_UPDATE:-False}"
export DFLASH_VERIFY_SKIP_MAX_CONSECUTIVE=2
export DFLASH_TEMPORAL_HOLD_ACTION_DECAY=inverse_age
export DFLASH_TEMPORAL_PREFILL_MIN_STABLE_ACTIONS=1
export DFLASH_TEMPORAL_ROUTE_LABEL=ContextualRisk
export RUN_ID_NOTE="${RUN_ID_NOTE:-dflash-vtpf-contextual-${TASK_SUITE_NAME:-libero_goal}-e${EVAL_EPOCH:-latest}-rho${DFLASH_CONTEXT_TARGET_DENSITY}}"

echo "[ContextualRisk] profile=${DFLASH_CONTEXT_RISK_PROFILE}"
echo "[ContextualRisk] target_density=${DFLASH_CONTEXT_TARGET_DENSITY} online_update=${DFLASH_CONTEXT_ONLINE_UPDATE}"

bash "${SCRIPT_DIR}/run_dflash_vtpf_adaptive_decimation_goal_eval.sh"
