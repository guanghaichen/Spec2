#!/usr/bin/env bash
set -euo pipefail

# 双反馈在线可恢复性推断的正式评测入口。
#
#   1. 局部非参数 UCB 从 Target 揭示的纠正标签在线学习上下文风险；
#   2. 状态转移观察器从每个环境步获得密集自监督；
#   3. 序贯风险证据与在线对偶变量共同分配 Target 计算预算；
#   4. 不使用离线 profile、固定节拍、固定最大复用深度或动作修正头。

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "${SPEC_CKPT:-}" ]]; then
  echo "请显式设置 SPEC_CKPT=/absolute/path/to/checkpoint。" >&2
  exit 1
fi

export DFLASH_CONTEXT_TARGET_DENSITY="${DFLASH_CONTEXT_TARGET_DENSITY:-0.4}"
export DFLASH_REVEALING_RISK_TARGET="${DFLASH_REVEALING_RISK_TARGET:-inverse_age_local}"
export DFLASH_REVEALING_HORIZON_MODE="${DFLASH_REVEALING_HORIZON_MODE:-observer_learned_survival}"
export DFLASH_REVEALING_RESIDUAL_MODE=False
export DFLASH_REVEALING_AUTHORITY_MODE=off
export DFLASH_REVEALING_AUTHORITY_MIN_DEPTH=1
export DFLASH_REVEALING_SELECTION_MODE="${DFLASH_REVEALING_SELECTION_MODE:-contextual}"
export DFLASH_TEMPORAL_HOLD_ACTION_DECAY=inverse_age
export DFLASH_TEMPORAL_ROUTE_LABEL=OnlineRecoverability
export RUN_ID_NOTE="${RUN_ID_NOTE:-dflash-vtpf-online-recoverability-${TASK_SUITE_NAME:-libero_goal}-e${EVAL_EPOCH:-latest}-rho${DFLASH_CONTEXT_TARGET_DENSITY}}"

echo "[OnlineRecoverability] target_density=${DFLASH_CONTEXT_TARGET_DENSITY}"
echo "[OnlineRecoverability] risk_target=${DFLASH_REVEALING_RISK_TARGET}"
echo "[OnlineRecoverability] horizon_mode=${DFLASH_REVEALING_HORIZON_MODE}"
echo "[OnlineRecoverability] selection_mode=${DFLASH_REVEALING_SELECTION_MODE}"
echo "[OnlineRecoverability] residual=${DFLASH_REVEALING_RESIDUAL_MODE} authority=${DFLASH_REVEALING_AUTHORITY_MODE}"

bash "${SCRIPT_DIR}/run_dflash_vtpf_revealing_goal_eval.sh"
