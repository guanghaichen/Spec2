#!/usr/bin/env bash
set -euo pipefail

# 在线揭示动作 VTPF：
# Target 调用会揭示历史动作在当前上下文中的反事实纠正误差；在线风险
# 模型据此更新，并在统一 Target 预算下自主选择后续 grounding 时刻。
# 不读取离线风险 profile，不使用固定节拍，也不使用任务成功标签。

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "${SPEC_CKPT:-}" ]]; then
  echo "请显式设置 SPEC_CKPT=/absolute/path/to/checkpoint。" >&2
  exit 1
fi

export DFLASH_TEMPORAL_HOLD_POLICY_OVERRIDE=True
export DFLASH_TEMPORAL_HOLD_POLICY=revealing_budget
export DFLASH_CONTEXT_RISK_PROFILE=""
export DFLASH_CONTEXT_TARGET_DENSITY="${DFLASH_CONTEXT_TARGET_DENSITY:-0.4}"
export DFLASH_CONTEXT_ONLINE_UPDATE=False
export DFLASH_REVEALING_RESIDUAL_MODE="${DFLASH_REVEALING_RESIDUAL_MODE:-False}"
export DFLASH_REVEALING_AUTHORITY_MODE="${DFLASH_REVEALING_AUTHORITY_MODE:-off}"
export DFLASH_REVEALING_SELECTION_MODE="${DFLASH_REVEALING_SELECTION_MODE:-contextual}"
export DFLASH_REVEALING_AUTHORITY_MIN_DEPTH="${DFLASH_REVEALING_AUTHORITY_MIN_DEPTH:-1}"
export DFLASH_VERIFY_SKIP_MAX_CONSECUTIVE=2
export DFLASH_TEMPORAL_HOLD_ACTION_DECAY=inverse_age
export DFLASH_TEMPORAL_PREFILL_MIN_STABLE_ACTIONS=1
export DFLASH_TEMPORAL_ROUTE_LABEL=RevealingBudget
export RUN_ID_NOTE="${RUN_ID_NOTE:-dflash-vtpf-revealing-${TASK_SUITE_NAME:-libero_goal}-e${EVAL_EPOCH:-latest}-rho${DFLASH_CONTEXT_TARGET_DENSITY}}"

echo "[RevealingBudget] target_density=${DFLASH_CONTEXT_TARGET_DENSITY}"
echo "[RevealingBudget] risk memory is learned online from Target calls"
echo "[RevealingBudget] residual_mode=${DFLASH_REVEALING_RESIDUAL_MODE}"
echo "[RevealingBudget] authority_mode=${DFLASH_REVEALING_AUTHORITY_MODE}"
echo "[RevealingBudget] selection_mode=${DFLASH_REVEALING_SELECTION_MODE}"
echo "[RevealingBudget] authority_min_depth=${DFLASH_REVEALING_AUTHORITY_MIN_DEPTH}"

bash "${SCRIPT_DIR}/run_dflash_vtpf_adaptive_decimation_goal_eval.sh"
