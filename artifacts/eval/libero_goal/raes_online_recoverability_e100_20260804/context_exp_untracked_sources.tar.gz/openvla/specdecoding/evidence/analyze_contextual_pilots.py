#!/usr/bin/env python3
"""Compare context-adaptive closed-loop pilots from saved eval summaries."""

from __future__ import annotations

import argparse
from itertools import combinations
import json
from pathlib import Path

import numpy as np


def average_ranks(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="stable")
    ranks = np.empty(len(values), dtype=np.float64)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        ranks[order[start:stop]] = 0.5 * (start + stop - 1)
        start = stop
    return ranks


def spearman(left: list[float], right: list[float]) -> float | None:
    if len(left) < 2 or len(left) != len(right):
        return None
    left_ranks = average_ranks(np.asarray(left, dtype=np.float64))
    right_ranks = average_ranks(np.asarray(right, dtype=np.float64))
    if left_ranks.std() == 0.0 or right_ranks.std() == 0.0:
        return None
    return float(np.corrcoef(left_ranks, right_ranks)[0, 1])


def episode_outcomes(summary: dict) -> dict[tuple[int, int], bool]:
    return {
        (int(item["task_id"]), int(item["trial_index"])): bool(item["success"])
        for item in summary.get("episode_results", [])
    }


def policy_records(summary: dict) -> list[dict]:
    full_generation = summary.get("generation_full_suite") or {}
    trace = full_generation.get("evidence_trace") or []
    traced = [
        item["temporal_hold_decision"]
        for item in trace
        if item.get("temporal_hold_decision") is not None
    ]
    if traced:
        return traced
    generation = summary.get("generation") or {}
    return list((generation.get("temporal_hold") or {}).get("records") or [])


def summarize_run(summary: dict, ar_mean_seconds: float | None) -> dict:
    generation = summary.get("generation_full_suite") or summary.get("generation") or {}
    hold = generation.get("temporal_hold") or {}
    risk = hold.get("revealing_risk") or hold.get("contextual_risk") or {}
    timing_mean = (summary.get("timing") or {}).get("mean")
    records = policy_records(summary)
    contextual_labeled = [
        record
        for record in records
        if record.get("contextual_risk_estimate") is not None
        and record.get("contextual_target_feedback") is not None
    ]
    revealing_labeled = [
        record
        for record in records
        if record.get("revealing_risk_estimate") is not None
        and record.get("revealing_target_feedback") is not None
    ]
    labeled = revealing_labeled or contextual_labeled
    feature_key = "revealing_features" if revealing_labeled else "contextual_features"
    estimate_key = (
        "revealing_risk_estimate"
        if revealing_labeled
        else "contextual_risk_estimate"
    )
    feedback_key = (
        "revealing_target_feedback"
        if revealing_labeled
        else "contextual_target_feedback"
    )
    true_correction = [
        float(record[feedback_key]["correction_l2"])
        for record in labeled
    ]
    feature_names = sorted(
        {
            name
            for record in labeled
            for name in (record.get(feature_key) or {})
        }
    )
    feature_correlations = {
        name: spearman(
            [float(record[feature_key][name]) for record in labeled],
            true_correction,
        )
        for name in feature_names
        if all(name in (record.get(feature_key) or {}) for record in labeled)
    }
    predicted = [
        float(
            record[estimate_key].get(
                "predicted_correction",
                record[estimate_key].get("correction_risk", 0.0),
            )
        )
        for record in labeled
    ]
    target_records = [record for record in records if not record.get("allow", False)]
    held_records = [record for record in records if record.get("allow", False)]
    utility_estimates = [
        record["vtpf_utility_estimate"]
        for record in records
        if record.get("vtpf_utility_estimate") is not None
    ]
    utility_feedback = [
        record["revealing_target_feedback"]["vtpf_utility_feedback"]
        for record in records
        if record.get("revealing_target_feedback") is not None
        and record["revealing_target_feedback"].get("vtpf_utility_feedback")
        is not None
    ]
    fused_actions = int(generation.get("temporal_prefill_fused_actions", 0))
    full_matches = int(generation.get("temporal_prefill_full_match_actions", 0))
    return {
        "task_suite_name": summary.get("task_suite_name"),
        "episodes": int(summary.get("total_episodes", 0)),
        "success_rate": summary.get("success_rate"),
        "timing_mean_seconds": timing_mean,
        "speedup_over_ar": (
            float(ar_mean_seconds) / float(timing_mean)
            if ar_mean_seconds is not None and timing_mean
            else None
        ),
        "length": generation.get("length"),
        "target_prefill_rate": hold.get("target_prefill_rate"),
        "target_actions": len(target_records),
        "held_actions": len(held_records),
        "temporal_prefill_fused_actions": fused_actions,
        "temporal_prefill_full_match_actions": full_matches,
        "temporal_prefill_full_match_rate": (
            full_matches / fused_actions if fused_actions else None
        ),
        "temporal_prefill_avg_accept_length": generation.get(
            "temporal_prefill_avg_accept_length"
        ),
        "extension_rate": hold.get("extension_rate"),
        "budget_error": risk.get("budget_error"),
        "selected_candidates": risk.get("selected_candidates"),
        "rejected_candidates": risk.get("rejected_candidates"),
        "avg_selected_risk": risk.get("avg_selected_risk"),
        "avg_rejected_risk": risk.get("avg_rejected_risk"),
        "avg_target_feedback_correction": risk.get(
            "avg_target_feedback_correction_l2"
        ),
        "labeled_context_records": len(labeled),
        "risk_feedback_type": "revealing" if revealing_labeled else "contextual",
        "predicted_vs_target_correction_spearman": spearman(
            predicted, true_correction
        ),
        "feature_vs_target_correction_spearman": feature_correlations,
        "vtpf_utility_estimate_records": len(utility_estimates),
        "vtpf_utility_feedback_records": len(utility_feedback),
        "vtpf_predicted_full_match_mean": (
            float(
                np.mean(
                    [item["full_match_probability"] for item in utility_estimates]
                )
            )
            if utility_estimates
            else None
        ),
    }


def paired_comparison(left: dict, right: dict) -> dict:
    left_outcomes = episode_outcomes(left)
    right_outcomes = episode_outcomes(right)
    shared = sorted(set(left_outcomes) & set(right_outcomes))
    return {
        "shared_episodes": len(shared),
        "both_success": sum(left_outcomes[key] and right_outcomes[key] for key in shared),
        "left_only_success": sum(
            left_outcomes[key] and not right_outcomes[key] for key in shared
        ),
        "right_only_success": sum(
            right_outcomes[key] and not left_outcomes[key] for key in shared
        ),
        "both_fail": sum(
            not left_outcomes[key] and not right_outcomes[key] for key in shared
        ),
    }


def parse_named_path(value: str) -> tuple[str, Path]:
    name, separator, path = value.partition("=")
    if not separator or not name or not path:
        raise argparse.ArgumentTypeError("Expected NAME=/absolute/summary.json")
    return name, Path(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="append", type=parse_named_path, required=True)
    parser.add_argument("--ar_summary", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    summaries = {
        name: json.loads(path.read_text()) for name, path in args.run
    }
    ar_mean = None
    if args.ar_summary is not None:
        ar_mean = float(json.loads(args.ar_summary.read_text())["timing"]["mean"])
    payload = {
        "claim_boundary": (
            "Closed-loop pilot comparison. Statistical claims require the frozen "
            "full evaluation protocol and confidence intervals."
        ),
        "ar_timing_mean_seconds": ar_mean,
        "runs": {
            name: summarize_run(summary, ar_mean)
            for name, summary in summaries.items()
        },
        "paired": {
            f"{left}_vs_{right}": paired_comparison(
                summaries[left], summaries[right]
            )
            for left, right in combinations(summaries, 2)
        },
    }
    rendered = json.dumps(payload, indent=2, ensure_ascii=False)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n")
    print(rendered)


if __name__ == "__main__":
    main()
