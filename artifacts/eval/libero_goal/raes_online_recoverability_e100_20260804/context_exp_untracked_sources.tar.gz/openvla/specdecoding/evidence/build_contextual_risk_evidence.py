#!/usr/bin/env python3
"""Build auditable evidence for context-adaptive hold allocation.

The input is a collection of target-only LIBERO traces produced by
``run_contextual_reference_trace.sh``.  The analysis keeps calibration and
evaluation seeds separate, predicts the continuous action correction required
after a hold, and compares allocation rules at exactly the same hold budget.
It never treats a target-only trace as a closed-loop policy result.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import rankdata, spearmanr
from sklearn.neighbors import NearestNeighbors

from openvla.specdecoding.evidence.plot_style import (
    COLORS,
    ICLR_DOUBLE_COLUMN_IN,
    iclr_style,
    save_figure,
)


SUITE_LABELS = {
    "libero_goal": "Goal",
    "libero_object": "Object",
    "libero_spatial": "Spatial",
    "libero_10": "Long",
}
FEATURES = (
    "image_relative_l2",
    "eef_position_l2",
    "eef_rotation_l2",
    "gripper_state_l2",
    "anchor_action_change_l2",
    "anchor_action_norm",
)
ENERGY_FEATURES = (
    "image_relative_l2",
    "eef_position_l2",
    "eef_rotation_l2",
    "anchor_action_change_l2",
    "anchor_action_norm",
)
SCORE_LABELS = {
    "visual": "Visual drift",
    "context_energy": "Context displacement",
    "local_quantile": "Local correction quantile",
    "local_mean": "Expected target correction",
    "chronological": "Uniform chronological",
    "oracle": "Oracle lower bound",
}
RISK_TARGETS = (
    "inverse_age_correction",
    "normalized_action_innovation",
)
LOCAL_RISK_STATISTICS = ("mean", "quantile")
RUNTIME_PROFILE_SCOPES = ("in_suite", "leave_one_suite_out")


def runtime_profile_filename(
    suite: str, *, calibration_scope: str, labels_shuffled: bool
) -> str:
    """Name negative controls explicitly, even when they are cross-suite."""
    if labels_shuffled:
        return f"context_risk_profile_shuffled_{suite}.json"
    if calibration_scope == "leave_one_suite_out":
        return f"context_risk_profile_transfer_to_{suite}.json"
    return f"context_risk_profile_{suite}.json"


@dataclass(frozen=True)
class RobustScale:
    median: np.ndarray
    scale: np.ndarray

    @classmethod
    def fit(cls, values: np.ndarray) -> "RobustScale":
        median = np.nanmedian(values, axis=0)
        mad = np.nanmedian(np.abs(values - median), axis=0) * 1.4826
        std = np.nanstd(values, axis=0)
        scale = np.where(mad > 1e-12, mad, np.where(std > 1e-12, std, 1.0))
        return cls(median=median, scale=scale)

    def transform(self, values: np.ndarray) -> np.ndarray:
        return (values - self.median) / self.scale


def parse_seed(path: Path) -> int:
    for part in reversed(path.parts):
        match = re.search(r"(?:^|[-_])s(\d+)(?:$|[-_])", part)
        if match:
            return int(match.group(1))
    raise ValueError(f"Cannot infer seed from trace path: {path}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def compute_risk_target(
    context_step: dict, lag_record: dict, risk_target: str
) -> float:
    if risk_target == "inverse_age_correction":
        return float(lag_record["inverse_age_action_correction_l2"])
    if risk_target == "normalized_action_innovation":
        denominator = (
            float(context_step["current_action_norm"])
            + float(lag_record["anchor_action_norm"])
            + 1e-8
        )
        continuous_innovation = min(
            1.0,
            float(lag_record["stale_action_correction_l2"]) / denominator,
        )
        return max(continuous_innovation, float(bool(lag_record["gripper_switch"])))
    raise ValueError(f"Unsupported risk_target: {risk_target}")


def load_rows(
    trace_root: Path, lag: int, risk_target: str
) -> tuple[list[dict], list[dict]]:
    rows: list[dict] = []
    sources: list[dict] = []
    for path in sorted(trace_root.rglob("*.jsonl")):
        if "smoke" in str(path).lower():
            continue
        seed = parse_seed(path)
        record_count = 0
        with path.open() as handle:
            for line_index, line in enumerate(handle):
                line = line.strip()
                if not line:
                    continue
                episode = json.loads(line)
                record_count += 1
                for context_step in episode.get("context_steps", []):
                    lag_record = next(
                        (
                            item
                            for item in context_step.get("lag_records", [])
                            if int(item["lag"]) == lag
                        ),
                        None,
                    )
                    if lag_record is None:
                        continue
                    row = {
                        "task_suite_name": str(episode["task_suite_name"]),
                        "task_id": int(episode["task_id"]),
                        "episode_index": int(episode["episode_index"]),
                        "episode_seed": int(episode["episode_seed"]),
                        "trace_seed": seed,
                        "step": int(context_step["step"]),
                        "lag": lag,
                        "success": bool(episode["success"]),
                        "source_path": str(path),
                        "source_line": line_index,
                        "risk_target": risk_target,
                        "correction_l2": compute_risk_target(
                            context_step, lag_record, risk_target
                        ),
                        "inverse_age_correction_l2": float(
                            lag_record["inverse_age_action_correction_l2"]
                        ),
                        "normalized_action_innovation": compute_risk_target(
                            context_step,
                            lag_record,
                            "normalized_action_innovation",
                        ),
                        "stale_correction_l2": float(
                            lag_record["stale_action_correction_l2"]
                        ),
                        "gripper_switch": bool(lag_record["gripper_switch"]),
                    }
                    for feature in FEATURES:
                        row[feature] = float(lag_record[feature])
                    rows.append(row)
        sources.append(
            {
                "path": str(path),
                "sha256": sha256(path),
                "episodes": record_count,
            }
        )
    if not rows:
        raise ValueError(f"No lag-{lag} context records found below {trace_root}")
    return rows, sources


def feature_matrix(rows: list[dict], names: Iterable[str] = FEATURES) -> np.ndarray:
    return np.asarray([[row[name] for name in names] for row in rows], dtype=np.float64)


def empirical_percentiles(calibration: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Map columns to calibration empirical CDF values without fitted weights."""
    output = np.empty_like(values, dtype=np.float64)
    for column in range(values.shape[1]):
        reference = np.sort(calibration[:, column])
        output[:, column] = np.searchsorted(
            reference, values[:, column], side="right"
        ) / max(len(reference), 1)
    return output


def auc_from_scores(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = labels.astype(bool)
    positives = int(labels.sum())
    negatives = int((~labels).sum())
    if positives == 0 or negatives == 0:
        return float("nan")
    ranks = rankdata(scores, method="average")
    return float(
        (ranks[labels].sum() - positives * (positives + 1) / 2)
        / (positives * negatives)
    )


def chronological_mask(rows: list[dict], count: int) -> np.ndarray:
    """Uniformly distribute a fixed number of selections over chronological order."""
    mask = np.zeros(len(rows), dtype=bool)
    if count <= 0:
        return mask
    order = np.lexsort(
        (
            np.asarray([row["step"] for row in rows]),
            np.asarray([row["episode_seed"] for row in rows]),
            np.asarray([row["task_id"] for row in rows]),
        )
    )
    positions = np.floor((np.arange(count) + 0.5) * len(rows) / count).astype(int)
    mask[order[np.minimum(positions, len(rows) - 1)]] = True
    return mask


def selection_mask(scores: np.ndarray, fraction: float) -> np.ndarray:
    count = int(round(float(fraction) * len(scores)))
    count = min(max(count, 1), len(scores))
    order = np.argsort(scores, kind="stable")
    mask = np.zeros(len(scores), dtype=bool)
    mask[order[:count]] = True
    return mask


def summarize_selection(
    suite: str,
    method: str,
    rows: list[dict],
    scores: np.ndarray,
    fraction: float,
    unsafe_threshold: float,
) -> dict:
    correction = np.asarray([row["correction_l2"] for row in rows])
    if method == "chronological":
        mask = chronological_mask(rows, int(round(fraction * len(rows))))
    else:
        mask = selection_mask(scores, fraction)
    selected = correction[mask]
    return {
        "task_suite_name": suite,
        "method": method,
        "requested_fraction": fraction,
        "selected_count": int(mask.sum()),
        "candidate_count": len(rows),
        "selected_fraction": float(mask.mean()),
        "mean_correction_l2": float(selected.mean()),
        "median_correction_l2": float(np.median(selected)),
        "p90_correction_l2": float(np.quantile(selected, 0.9)),
        "unsafe_fraction": float((selected >= unsafe_threshold).mean()),
        "gripper_switch_fraction": float(
            np.mean([rows[index]["gripper_switch"] for index in np.flatnonzero(mask)])
        ),
    }


def score_suite(
    suite: str,
    calibration_rows: list[dict],
    evaluation_rows: list[dict],
    extension_fraction: float,
    unsafe_quantile: float,
) -> tuple[list[dict], list[dict]]:
    feature_names = list(FEATURES)
    energy_indices = [feature_names.index(name) for name in ENERGY_FEATURES]
    x_cal = feature_matrix(calibration_rows)
    x_eval = feature_matrix(evaluation_rows)
    y_cal = np.asarray([row["correction_l2"] for row in calibration_rows])
    y_eval = np.asarray([row["correction_l2"] for row in evaluation_rows])
    unsafe_threshold = float(np.quantile(y_cal, unsafe_quantile))
    unsafe_eval = y_eval >= unsafe_threshold

    percentile_eval = empirical_percentiles(x_cal, x_eval)
    visual_score = percentile_eval[:, feature_names.index("image_relative_l2")]
    energy_score = np.sqrt(
        np.mean(np.square(percentile_eval[:, energy_indices]), axis=1)
    )

    robust = RobustScale.fit(x_cal[:, energy_indices])
    z_cal = robust.transform(x_cal[:, energy_indices])
    z_eval = robust.transform(x_eval[:, energy_indices])
    neighbors = max(16, int(round(math.sqrt(len(calibration_rows)))))
    neighbors = min(neighbors, len(calibration_rows))
    index = NearestNeighbors(n_neighbors=neighbors, algorithm="auto").fit(z_cal)
    neighbor_ids = index.kneighbors(z_eval, return_distance=False)
    local_corrections = y_cal[neighbor_ids]
    local_score = np.quantile(local_corrections, unsafe_quantile, axis=1)
    local_mean_score = np.mean(local_corrections, axis=1)

    score_map = {
        "visual": visual_score,
        "context_energy": energy_score,
        "local_quantile": local_score,
        "local_mean": local_mean_score,
        "oracle": y_eval,
    }
    discrimination = []
    for method, score in score_map.items():
        correlation = spearmanr(score, y_eval, nan_policy="omit").statistic
        discrimination.append(
            {
                "task_suite_name": suite,
                "method": method,
                "calibration_count": len(calibration_rows),
                "evaluation_count": len(evaluation_rows),
                "unsafe_quantile": unsafe_quantile,
                "unsafe_threshold": unsafe_threshold,
                "unsafe_prevalence": float(unsafe_eval.mean()),
                "auc": auc_from_scores(unsafe_eval, score),
                "spearman": float(correlation),
                "knn_neighbors": neighbors if method == "local_quantile" else "",
            }
        )

    allocation = [
        summarize_selection(
            suite,
            "chronological",
            evaluation_rows,
            np.zeros_like(y_eval),
            extension_fraction,
            unsafe_threshold,
        )
    ]
    for method, score in score_map.items():
        allocation.append(
            summarize_selection(
                suite,
                method,
                evaluation_rows,
                score,
                extension_fraction,
                unsafe_threshold,
            )
        )
    return discrimination, allocation


def build_runtime_profile(
    *,
    suite: str,
    calibration_rows: list[dict],
    calibration_seed: int,
    unsafe_quantile: float,
    lag: int,
    risk_target: str = "inverse_age_correction",
    local_risk_statistic: str = "quantile",
    calibration_scope: str = "in_suite",
    source_task_suites: Iterable[str] = (),
    shuffle_labels: bool = False,
    shuffle_seed: int = 7,
) -> dict:
    """Serialize the nonparametric memory used by the online risk allocator."""
    feature_names = list(FEATURES)
    energy_indices = [feature_names.index(name) for name in ENERGY_FEATURES]
    values = feature_matrix(calibration_rows)[:, energy_indices]
    correction = np.asarray(
        [row["correction_l2"] for row in calibration_rows], dtype=np.float64
    )
    if local_risk_statistic not in LOCAL_RISK_STATISTICS:
        raise ValueError(
            f"local_risk_statistic must be one of {LOCAL_RISK_STATISTICS}."
        )
    if calibration_scope not in RUNTIME_PROFILE_SCOPES:
        raise ValueError(
            f"calibration_scope must be one of {RUNTIME_PROFILE_SCOPES}."
        )
    if shuffle_labels:
        correction = np.random.default_rng(int(shuffle_seed)).permutation(correction)
    robust = RobustScale.fit(values)
    normalized = robust.transform(values)
    neighbors = max(16, int(round(math.sqrt(len(calibration_rows)))))
    neighbors = min(neighbors, max(len(calibration_rows) - 1, 1))
    query_count = min(neighbors + 1, len(calibration_rows))
    index = NearestNeighbors(n_neighbors=query_count, algorithm="auto").fit(
        normalized
    )
    raw_neighbor_ids = index.kneighbors(normalized, return_distance=False)
    leave_one_out_ids = []
    for row_index, candidates in enumerate(raw_neighbor_ids):
        filtered = [int(value) for value in candidates if int(value) != row_index]
        if not filtered:
            filtered = [row_index]
        leave_one_out_ids.append(filtered[:neighbors])
    if local_risk_statistic == "mean":
        reference_scores = np.asarray(
            [np.mean(correction[indices]) for indices in leave_one_out_ids],
            dtype=np.float64,
        )
    else:
        reference_scores = np.asarray(
            [
                np.quantile(correction[indices], unsafe_quantile)
                for indices in leave_one_out_ids
            ],
            dtype=np.float64,
        )
    return {
        "schema_version": 1,
        "task_suite_name": suite,
        "lag": int(lag),
        "calibration_seed": int(calibration_seed),
        "risk_target": risk_target,
        "local_risk_statistic": local_risk_statistic,
        "calibration_scope": calibration_scope,
        "source_task_suites": sorted(set(source_task_suites)),
        "profile_labels_shuffled": bool(shuffle_labels),
        "profile_shuffle_seed": int(shuffle_seed) if shuffle_labels else None,
        "feature_names": list(ENERGY_FEATURES),
        "robust_median": np.round(robust.median, 10).tolist(),
        "robust_scale": np.round(robust.scale, 10).tolist(),
        "normalized_contexts": np.round(normalized, 7).tolist(),
        "correction_l2": np.round(correction, 7).tolist(),
        "risk_reference": np.round(np.sort(reference_scores), 7).tolist(),
        "neighbors": int(neighbors),
        "local_risk_quantile": (
            float(unsafe_quantile) if local_risk_statistic == "quantile" else None
        ),
        "online_update": {
            "enabled": False,
            "label_source": "optional target feedback after a denied depth-2 hold",
            "max_online_records": 512,
        },
        "claim_boundary": (
            f"Predicts {risk_target}. Closed-loop task risk and "
            "speedup require separate paired evaluation."
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def plot_discrimination(rows: list[dict], output_stem: Path) -> None:
    suites = sorted({row["task_suite_name"] for row in rows})
    methods = ["visual", "context_energy", "local_mean"]
    colors = [COLORS["blue"], COLORS["orange"], COLORS["green"]]
    x = np.arange(len(suites))
    width = 0.23
    with iclr_style():
        fig, axes = plt.subplots(1, 2, figsize=(ICLR_DOUBLE_COLUMN_IN, 2.45))
        for offset, (method, color) in enumerate(zip(methods, colors)):
            selected = {
                row["task_suite_name"]: row
                for row in rows
                if row["method"] == method
            }
            axes[0].bar(
                x + (offset - 1) * width,
                [selected[suite]["auc"] for suite in suites],
                width,
                color=color,
                label=SCORE_LABELS[method],
            )
            axes[1].bar(
                x + (offset - 1) * width,
                [selected[suite]["spearman"] for suite in suites],
                width,
                color=color,
            )
        axes[0].axhline(0.5, color=COLORS["gray"], linestyle="--", linewidth=0.8)
        axes[0].set_ylabel("Unsafe-hold AUROC")
        axes[1].set_ylabel("Spearman with correction")
        for axis in axes:
            axis.set_xticks(x, [SUITE_LABELS.get(suite, suite) for suite in suites])
            axis.grid(axis="y")
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(
            handles,
            labels,
            frameon=False,
            loc="upper center",
            bbox_to_anchor=(0.5, 1.01),
            ncol=3,
        )
        fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.86), w_pad=1.1)
        save_figure(fig, output_stem)
        plt.close(fig)


def plot_allocation(rows: list[dict], output_stem: Path) -> None:
    suites = sorted({row["task_suite_name"] for row in rows})
    methods = ["chronological", "visual", "context_energy", "local_mean"]
    colors = [COLORS["gray"], COLORS["blue"], COLORS["orange"], COLORS["green"]]
    x = np.arange(len(suites))
    width = 0.19
    with iclr_style():
        fig, axes = plt.subplots(1, 2, figsize=(ICLR_DOUBLE_COLUMN_IN, 2.45))
        for offset, (method, color) in enumerate(zip(methods, colors)):
            selected = {
                row["task_suite_name"]: row
                for row in rows
                if row["method"] == method
            }
            positions = x + (offset - 1.5) * width
            axes[0].bar(
                positions,
                [selected[suite]["mean_correction_l2"] for suite in suites],
                width,
                color=color,
                label=SCORE_LABELS[method],
            )
            axes[1].bar(
                positions,
                [selected[suite]["unsafe_fraction"] for suite in suites],
                width,
                color=color,
            )
        axes[0].set_ylabel("Selected correction L2")
        axes[1].set_ylabel("Selected unsafe fraction")
        for axis in axes:
            axis.set_xticks(x, [SUITE_LABELS.get(suite, suite) for suite in suites])
            axis.grid(axis="y")
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(
            handles,
            labels,
            frameon=False,
            loc="upper center",
            bbox_to_anchor=(0.5, 1.01),
            ncol=4,
        )
        fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.86), w_pad=1.1)
        save_figure(fig, output_stem)
        plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace_root", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--lag", type=int, default=2)
    parser.add_argument("--calibration_seed", type=int, default=7)
    parser.add_argument("--extension_fraction", type=float, default=0.48)
    parser.add_argument("--unsafe_quantile", type=float, default=0.75)
    parser.add_argument(
        "--risk_target",
        choices=RISK_TARGETS,
        default="inverse_age_correction",
    )
    parser.add_argument(
        "--local_risk_statistic",
        choices=LOCAL_RISK_STATISTICS,
        default="quantile",
        help=(
            "Runtime value estimator. 'mean' estimates expected Target correction; "
            "'quantile' preserves the original upper-quantile risk score."
        ),
    )
    parser.add_argument(
        "--runtime_profile_scope",
        choices=RUNTIME_PROFILE_SCOPES,
        default="in_suite",
        help=(
            "Use the held suite itself or the other suites as the runtime memory. "
            "The latter is a leave-one-suite-out transfer test."
        ),
    )
    parser.add_argument(
        "--shuffle_profile_labels",
        action="store_true",
        help="Permute correction labels while preserving contexts and label marginals.",
    )
    parser.add_argument("--profile_shuffle_seed", type=int, default=7)
    args = parser.parse_args()
    if not 0.0 < args.extension_fraction <= 1.0:
        raise ValueError("extension_fraction must be in (0, 1]")
    if not 0.5 <= args.unsafe_quantile < 1.0:
        raise ValueError("unsafe_quantile must be in [0.5, 1)")

    rows, sources = load_rows(args.trace_root, args.lag, args.risk_target)
    suites = sorted({row["task_suite_name"] for row in rows})
    discrimination: list[dict] = []
    allocation: list[dict] = []
    split_manifest = []
    profile_paths = []
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for suite in suites:
        suite_rows = [row for row in rows if row["task_suite_name"] == suite]
        calibration_rows = [
            row for row in suite_rows if row["trace_seed"] == args.calibration_seed
        ]
        evaluation_rows = [
            row for row in suite_rows if row["trace_seed"] != args.calibration_seed
        ]
        if not calibration_rows or not evaluation_rows:
            continue
        suite_discrimination, suite_allocation = score_suite(
            suite,
            calibration_rows,
            evaluation_rows,
            args.extension_fraction,
            args.unsafe_quantile,
        )
        discrimination.extend(suite_discrimination)
        allocation.extend(suite_allocation)
        if args.runtime_profile_scope == "leave_one_suite_out":
            profile_rows = [
                row
                for row in rows
                if row["task_suite_name"] != suite
                and row["trace_seed"] == args.calibration_seed
            ]
            source_task_suites = sorted(
                {row["task_suite_name"] for row in profile_rows}
            )
        else:
            profile_rows = calibration_rows
            source_task_suites = [suite]
        if not profile_rows:
            continue
        profile = build_runtime_profile(
            suite=suite,
            calibration_rows=profile_rows,
            calibration_seed=args.calibration_seed,
            unsafe_quantile=args.unsafe_quantile,
            lag=args.lag,
            risk_target=args.risk_target,
            local_risk_statistic=args.local_risk_statistic,
            calibration_scope=args.runtime_profile_scope,
            source_task_suites=source_task_suites,
            shuffle_labels=args.shuffle_profile_labels,
            shuffle_seed=args.profile_shuffle_seed + suites.index(suite),
        )
        profile_name = runtime_profile_filename(
            suite,
            calibration_scope=args.runtime_profile_scope,
            labels_shuffled=args.shuffle_profile_labels,
        )
        profile_path = args.output_dir / profile_name
        profile_path.write_text(json.dumps(profile, separators=(",", ":")) + "\n")
        profile_paths.append(str(profile_path))
        split_manifest.append(
            {
                "task_suite_name": suite,
                "calibration_seed": args.calibration_seed,
                "evaluation_seeds": sorted(
                    {row["trace_seed"] for row in evaluation_rows}
                ),
                "calibration_candidates": len(calibration_rows),
                "evaluation_candidates": len(evaluation_rows),
            }
        )

    write_csv(args.output_dir / "context_candidates.csv", rows)
    write_csv(args.output_dir / "risk_discrimination.csv", discrimination)
    write_csv(args.output_dir / "equal_budget_allocation.csv", allocation)
    manifest = {
        "claim_boundary": (
            "Target-only correction prediction and equal-budget allocation proxy; "
            "not a closed-loop success-rate or speedup result."
        ),
        "lag": args.lag,
        "calibration_seed": args.calibration_seed,
        "extension_fraction": args.extension_fraction,
        "unsafe_quantile": args.unsafe_quantile,
        "risk_target": args.risk_target,
        "local_risk_statistic": args.local_risk_statistic,
        "runtime_profile_scope": args.runtime_profile_scope,
        "shuffle_profile_labels": args.shuffle_profile_labels,
        "profile_shuffle_seed": args.profile_shuffle_seed,
        "splits": split_manifest,
        "runtime_profiles": profile_paths,
        "sources": sources,
    }
    (args.output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    if discrimination:
        plot_discrimination(
            discrimination, args.output_dir / "context_risk_discrimination"
        )
        plot_allocation(allocation, args.output_dir / "equal_budget_allocation")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
