#!/usr/bin/env python3
"""Replay target-only traces as a one-sided revealing-action problem."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from openvla.specdecoding.model.revealing_action import (
    OnlineRevealingRiskModel,
    OnlineTargetBudgetAllocator,
)


FEATURE_NAMES = (
    "image_relative_l2",
    "eef_position_l2",
    "eef_rotation_l2",
    "anchor_action_change_l2",
    "anchor_action_norm",
    "candidate_hold_depth",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("traces", nargs="+", type=Path)
    parser.add_argument("--target-density", type=float, default=0.4032258064516129)
    parser.add_argument("--confidence-scale", type=float, default=1.0)
    parser.add_argument("--unsafe-correction", type=float, default=0.5)
    parser.add_argument("--carry-across-episodes", action="store_true")
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def iter_episodes(paths: list[Path]):
    for path in paths:
        with path.open() as handle:
            for line in handle:
                record = json.loads(line)
                if record.get("record_type") == "episode":
                    yield record


def lag_record(step: dict, lag: int) -> dict | None:
    for record in step.get("lag_records", []):
        if int(record.get("lag", -1)) == int(lag):
            return record
    return None


def features(record: dict) -> dict[str, float]:
    result = {
        name: float(record[name])
        for name in FEATURE_NAMES
        if name != "candidate_hold_depth"
    }
    result["candidate_hold_depth"] = float(record["lag"])
    return result


def summarize(values: list[float], unsafe_threshold: float) -> dict:
    array = np.asarray(values, dtype=np.float64)
    if not len(array):
        return {"count": 0, "mean": None, "median": None, "unsafe_fraction": None}
    return {
        "count": int(len(array)),
        "mean": float(np.mean(array)),
        "median": float(np.median(array)),
        "unsafe_fraction": float(np.mean(array > unsafe_threshold)),
    }


def main() -> None:
    args = parse_args()
    model = OnlineRevealingRiskModel(
        FEATURE_NAMES, confidence_scale=args.confidence_scale
    )
    allocator = OnlineTargetBudgetAllocator(args.target_density)
    target_labels: list[float] = []
    hold_labels: list[float] = []
    all_labels: list[float] = []
    predicted: list[float] = []
    observed: list[float] = []
    episode_summaries = []

    for episode_index, episode in enumerate(iter_episodes(args.traces)):
        if not args.carry_across_episodes or episode_index == 0:
            model.reset()
            allocator.reset()
        consecutive_holds = 0
        episode_targets = 0
        episode_holds = 0
        for step in episode.get("context_steps", []):
            lag = consecutive_holds + 1
            record = lag_record(step, lag)
            eligible = record is not None and consecutive_holds < 2
            if record is None:
                estimate = None
                risk_percentile = 1.0
                model_ready = False
            else:
                estimate = model.estimate(features(record))
                risk_percentile = estimate.risk_percentile
                model_ready = estimate.ready
                if estimate.ready:
                    predicted.append(estimate.upper_confidence_risk)
                    observed.append(float(record["inverse_age_action_correction_l2"]))
            decision = allocator.decide(
                risk_percentile, eligible=eligible, model_ready=model_ready
            )
            if record is not None:
                label = float(record["inverse_age_action_correction_l2"])
                all_labels.append(label)
            else:
                label = None
            if decision.allow_hold:
                assert label is not None
                hold_labels.append(label)
                episode_holds += 1
                consecutive_holds += 1
            else:
                episode_targets += 1
                if label is not None:
                    target_labels.append(label)
                    model.observe(features(record), label)
                consecutive_holds = 0
        episode_summaries.append(
            {
                "task_id": int(episode["task_id"]),
                "episode_index": int(episode["episode_index"]),
                "steps": int(episode_targets + episode_holds),
                "targets": int(episode_targets),
                "holds": int(episode_holds),
                "target_density": float(
                    episode_targets / max(episode_targets + episode_holds, 1)
                ),
            }
        )

    correlation = None
    if len(predicted) >= 3:
        predicted_ranks = np.argsort(np.argsort(np.asarray(predicted)))
        observed_ranks = np.argsort(np.argsort(np.asarray(observed)))
        correlation = float(np.corrcoef(predicted_ranks, observed_ranks)[0, 1])
    decisions = len(target_labels) + len(hold_labels)
    result = {
        "method": "online_revealing_action_replay",
        "trace_files": [str(path) for path in args.traces],
        "target_density_budget": args.target_density,
        "carry_across_episodes": bool(args.carry_across_episodes),
        "episodes": len(episode_summaries),
        "labeled_decisions": decisions,
        "realized_target_density_on_labeled_decisions": (
            len(target_labels) / decisions if decisions else None
        ),
        "targeted_contexts": summarize(target_labels, args.unsafe_correction),
        "held_contexts": summarize(hold_labels, args.unsafe_correction),
        "all_contexts": summarize(all_labels, args.unsafe_correction),
        "prequential_spearman": correlation,
        "episode_summaries": episode_summaries,
    }
    rendered = json.dumps(result, indent=2)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n")
    print(rendered)


if __name__ == "__main__":
    main()
