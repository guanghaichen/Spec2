"""Nonparametric contextual risk and online compute-budget allocation.

This module is intentionally independent of the VLA model and simulator.  A
frozen target-only calibration memory provides the risk geometry, while an
online dual variable allocates a requested fraction of depth-two holds to the
lowest-risk contexts observed during execution.  Selective target-feedback
writeback is supported only as an explicit ablation because its labels are not
missing at random.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Mapping, Optional

import numpy as np


@dataclass(frozen=True)
class ContextRiskEstimate:
    risk_target: str
    risk_statistic: str
    correction_risk: float
    risk_percentile: float
    nearest_distance: float
    neighbors: int
    calibration_records: int
    online_records: int

    def as_record(self) -> dict:
        return {
            "risk_target": self.risk_target,
            "risk_statistic": self.risk_statistic,
            "correction_risk": self.correction_risk,
            "risk_percentile": self.risk_percentile,
            "nearest_distance": self.nearest_distance,
            "neighbors": self.neighbors,
            "calibration_records": self.calibration_records,
            "online_records": self.online_records,
        }


@dataclass(frozen=True)
class ContextualBudgetDecision:
    allow: bool
    risk_percentile: float
    dual_threshold_before: float
    dual_threshold_after: float
    desired_extension_fraction: float
    candidate_count: int
    selected_count: int
    effective_prior_count: int
    step_size: float

    def as_record(self) -> dict:
        return {
            "allow": self.allow,
            "risk_percentile": self.risk_percentile,
            "dual_threshold_before": self.dual_threshold_before,
            "dual_threshold_after": self.dual_threshold_after,
            "desired_extension_fraction": self.desired_extension_fraction,
            "candidate_count": self.candidate_count,
            "selected_count": self.selected_count,
            "effective_prior_count": self.effective_prior_count,
            "step_size": self.step_size,
            "realized_extension_fraction": (
                self.selected_count / self.candidate_count
                if self.candidate_count
                else 0.0
            ),
        }


class ContextualRiskMemory:
    """A compact k-nearest-neighbor correction-risk memory."""

    def __init__(self, profile: Mapping) -> None:
        if int(profile.get("schema_version", -1)) != 1:
            raise ValueError("Unsupported contextual-risk profile schema.")
        self.task_suite_name = str(profile["task_suite_name"])
        self.risk_target = str(
            profile.get("risk_target", "inverse_age_correction")
        )
        self.risk_statistic = str(
            profile.get("local_risk_statistic", "quantile")
        )
        self.feature_names = tuple(str(value) for value in profile["feature_names"])
        self.median = np.asarray(profile["robust_median"], dtype=np.float64)
        self.scale = np.asarray(profile["robust_scale"], dtype=np.float64)
        self._calibration_contexts = np.asarray(
            profile["normalized_contexts"], dtype=np.float64
        )
        self._calibration_corrections = np.asarray(
            profile["correction_l2"], dtype=np.float64
        )
        self._risk_reference = np.asarray(
            profile["risk_reference"], dtype=np.float64
        )
        self.neighbors = int(profile["neighbors"])
        quantile_value = profile.get("local_risk_quantile", 0.75)
        self.local_risk_quantile = (
            None if quantile_value is None else float(quantile_value)
        )
        online_config = profile.get("online_update", {})
        self.max_online_records = int(online_config.get("max_online_records", 512))
        self._online_contexts: list[np.ndarray] = []
        self._online_corrections: list[float] = []
        self._validate()

    @classmethod
    def from_path(cls, path: str | Path) -> "ContextualRiskMemory":
        return cls(json.loads(Path(path).read_text()))

    def _validate(self) -> None:
        if self.risk_target not in {
            "inverse_age_correction",
            "normalized_action_innovation",
        }:
            raise ValueError(
                f"Unsupported contextual-risk target: {self.risk_target}"
            )
        if self.risk_statistic not in {"mean", "quantile"}:
            raise ValueError(
                f"Unsupported local-risk statistic: {self.risk_statistic}"
            )
        width = len(self.feature_names)
        if not width:
            raise ValueError("Contextual-risk profile has no features.")
        if self.median.shape != (width,) or self.scale.shape != (width,):
            raise ValueError("Robust scale does not match feature_names.")
        if np.any(~np.isfinite(self.scale)) or np.any(self.scale <= 0.0):
            raise ValueError("Robust scales must be finite and positive.")
        if self._calibration_contexts.ndim != 2 or self._calibration_contexts.shape[1] != width:
            raise ValueError("Calibration contexts have the wrong shape.")
        if len(self._calibration_contexts) != len(self._calibration_corrections):
            raise ValueError("Calibration contexts and corrections differ in length.")
        if len(self._calibration_contexts) < 2:
            raise ValueError("At least two calibration records are required.")
        if self.risk_statistic == "quantile" and (
            self.local_risk_quantile is None
            or not 0.5 <= self.local_risk_quantile < 1.0
        ):
            raise ValueError("local_risk_quantile must lie in [0.5, 1).")
        if self.neighbors < 1:
            raise ValueError("neighbors must be positive.")
        if len(self._risk_reference) < 2 or np.any(np.diff(self._risk_reference) < 0):
            raise ValueError("risk_reference must be a sorted nontrivial array.")

    @property
    def calibration_records(self) -> int:
        return len(self._calibration_corrections)

    @property
    def online_records(self) -> int:
        return len(self._online_corrections)

    def reset_online(self) -> None:
        self._online_contexts.clear()
        self._online_corrections.clear()

    def vectorize(self, features: Mapping[str, float]) -> np.ndarray:
        missing = [name for name in self.feature_names if name not in features]
        if missing:
            raise ValueError(f"Missing contextual-risk features: {missing}")
        raw = np.asarray([features[name] for name in self.feature_names], dtype=np.float64)
        if np.any(~np.isfinite(raw)):
            raise ValueError("Contextual-risk features must be finite.")
        return (raw - self.median) / self.scale

    def _all_records(self) -> tuple[np.ndarray, np.ndarray]:
        if not self._online_contexts:
            return self._calibration_contexts, self._calibration_corrections
        return (
            np.concatenate(
                [self._calibration_contexts, np.stack(self._online_contexts)], axis=0
            ),
            np.concatenate(
                [self._calibration_corrections, np.asarray(self._online_corrections)]
            ),
        )

    def estimate(self, features: Mapping[str, float]) -> ContextRiskEstimate:
        query = self.vectorize(features)
        contexts, corrections = self._all_records()
        squared_distance = np.sum(np.square(contexts - query[None, :]), axis=1)
        count = min(self.neighbors, len(contexts))
        neighbor_ids = np.argpartition(squared_distance, count - 1)[:count]
        local_corrections = corrections[neighbor_ids]
        if self.risk_statistic == "mean":
            risk = float(np.mean(local_corrections))
        else:
            assert self.local_risk_quantile is not None
            risk = float(
                np.quantile(local_corrections, self.local_risk_quantile)
            )
        percentile = float(
            np.searchsorted(self._risk_reference, risk, side="right")
            / len(self._risk_reference)
        )
        return ContextRiskEstimate(
            risk_target=self.risk_target,
            risk_statistic=self.risk_statistic,
            correction_risk=risk,
            risk_percentile=percentile,
            nearest_distance=float(math.sqrt(float(squared_distance[neighbor_ids].min()))),
            neighbors=count,
            calibration_records=self.calibration_records,
            online_records=self.online_records,
        )

    def observe(self, features: Mapping[str, float], correction_l2: float) -> None:
        correction_l2 = float(correction_l2)
        if not math.isfinite(correction_l2) or correction_l2 < 0.0:
            raise ValueError("correction_l2 must be finite and non-negative.")
        self._online_contexts.append(self.vectorize(features))
        self._online_corrections.append(correction_l2)
        overflow = len(self._online_corrections) - self.max_online_records
        if overflow > 0:
            del self._online_contexts[:overflow]
            del self._online_corrections[:overflow]


class OnlineBudgetAllocator:
    """Online primal-dual allocator for a target extension fraction.

    Risk percentiles live in ``[0, 1]``, so the projected ``1 / sqrt(n)``
    update is dimensionless. The dual threshold rises when the allocator is
    behind its requested hold budget and falls when it is ahead. Decisions
    depend on the observed risk stream and budget state; no temporal schedule
    is stored or replayed.
    """

    def __init__(
        self,
        desired_extension_fraction: float,
        effective_prior_count: int = 0,
    ) -> None:
        fraction = float(desired_extension_fraction)
        if not 0.0 <= fraction <= 1.0:
            raise ValueError("desired_extension_fraction must lie in [0, 1].")
        self.desired_extension_fraction = fraction
        self.effective_prior_count = int(effective_prior_count)
        if self.effective_prior_count < 0:
            raise ValueError("effective_prior_count must be non-negative.")
        self.reset()

    def reset(self) -> None:
        self.dual_threshold = self.desired_extension_fraction
        self.candidate_count = 0
        self.selected_count = 0

    def decide(self, risk_percentile: float) -> ContextualBudgetDecision:
        risk_percentile = float(risk_percentile)
        if not 0.0 <= risk_percentile <= 1.0 or not math.isfinite(risk_percentile):
            raise ValueError("risk_percentile must be finite and lie in [0, 1].")
        threshold_before = self.dual_threshold
        allow = risk_percentile <= threshold_before
        self.candidate_count += 1
        self.selected_count += int(allow)
        step_size = (
            self.effective_prior_count + self.candidate_count
        ) ** -0.5
        self.dual_threshold = min(
            1.0,
            max(
                0.0,
                threshold_before
                + step_size
                * (self.desired_extension_fraction - float(allow)),
            ),
        )
        return ContextualBudgetDecision(
            allow=allow,
            risk_percentile=risk_percentile,
            dual_threshold_before=threshold_before,
            dual_threshold_after=self.dual_threshold,
            desired_extension_fraction=self.desired_extension_fraction,
            candidate_count=self.candidate_count,
            selected_count=self.selected_count,
            effective_prior_count=self.effective_prior_count,
            step_size=step_size,
        )


def extension_fraction_from_target_density(target_density: float) -> float:
    """Map T-H1-(optional H2) target density to the H2 allocation budget."""
    density = float(target_density)
    if not 1.0 / 3.0 <= density <= 1.0 / 2.0:
        raise ValueError("target_density must lie in [1/3, 1/2].")
    return 1.0 / density - 2.0
