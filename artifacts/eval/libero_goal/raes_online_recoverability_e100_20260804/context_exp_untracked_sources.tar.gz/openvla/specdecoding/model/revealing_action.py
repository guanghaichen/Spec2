"""Online contextual risk learning from target-revealing actions.

Calling the target model reveals both the target action and the error that a
cheap held action would have made.  This module treats target invocation as a
revealing action: queried contexts update a small online risk model, while a
primal-dual allocator spends a requested target-call budget on contexts with
the largest predicted hold risk.  No temporal schedule or task-specific risk
threshold is represented here.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping, Sequence

import numpy as np


@dataclass(frozen=True)
class RevealingRiskEstimate:
    """One pre-target estimate of the cost of reusing a held action."""

    ready: bool
    predicted_correction: float
    epistemic_uncertainty: float
    upper_confidence_risk: float
    risk_percentile: float
    labeled_records: int
    feature_dimension: int

    def as_record(self) -> dict:
        return {
            "ready": self.ready,
            "predicted_correction": self.predicted_correction,
            "epistemic_uncertainty": self.epistemic_uncertainty,
            "upper_confidence_risk": self.upper_confidence_risk,
            "risk_percentile": self.risk_percentile,
            "labeled_records": self.labeled_records,
            "feature_dimension": self.feature_dimension,
        }


def select_monotone_risk_envelope(
    estimates: Sequence[RevealingRiskEstimate],
) -> tuple[int, RevealingRiskEstimate]:
    """Return the prefix depth carrying the largest conservative risk."""

    if not estimates:
        raise ValueError("estimates must contain at least one depth.")
    index = max(
        range(len(estimates)),
        key=lambda item: estimates[item].upper_confidence_risk,
    )
    return index + 1, estimates[index]


def accumulate_recoverability_hazard(
    survival_before: float,
    instantaneous_risk: float,
) -> tuple[float, float]:
    """Compose sequential conditional risk without a fixed hold horizon."""

    survival = float(survival_before)
    risk = float(instantaneous_risk)
    if not math.isfinite(survival) or not 0.0 <= survival <= 1.0:
        raise ValueError("survival_before must lie in [0, 1].")
    if not math.isfinite(risk) or not 0.0 <= risk <= 1.0:
        raise ValueError("instantaneous_risk must lie in [0, 1].")
    survival_after = survival * (1.0 - risk)
    return 1.0 - survival_after, survival_after


@dataclass(frozen=True)
class RevealingBudgetDecision:
    """One globally budgeted hold/target decision."""

    allow_hold: bool
    reason: str
    risk_percentile: float
    threshold_before: float
    threshold_after: float
    desired_target_density: float
    decision_count: int
    hold_count: int
    target_count: int
    step_size: float

    def as_record(self) -> dict:
        return {
            "allow_hold": self.allow_hold,
            "reason": self.reason,
            "risk_percentile": self.risk_percentile,
            "threshold_before": self.threshold_before,
            "threshold_after": self.threshold_after,
            "desired_target_density": self.desired_target_density,
            "decision_count": self.decision_count,
            "hold_count": self.hold_count,
            "target_count": self.target_count,
            "realized_target_density": self.target_count / self.decision_count,
            "step_size": self.step_size,
        }


@dataclass(frozen=True)
class RevealingResidualEstimate:
    """Pre-target estimate of the vector correction for a held action."""

    ready: bool
    predicted_residual: tuple[float, ...]
    predicted_residual_l2: float
    learned_authority: float
    labeled_records: int
    prequential_records: int

    def as_record(self) -> dict:
        return {
            "ready": self.ready,
            "predicted_residual": list(self.predicted_residual),
            "predicted_residual_l2": self.predicted_residual_l2,
            "learned_authority": self.learned_authority,
            "labeled_records": self.labeled_records,
            "prequential_records": self.prequential_records,
        }


@dataclass(frozen=True)
class RevealingAuthorityEstimate:
    """Online estimate of how much target-grounded action authority to retain."""

    ready: bool
    certified: bool
    predicted_authority: float
    labeled_records: int
    prequential_records: int

    def as_record(self) -> dict:
        return {
            "ready": self.ready,
            "certified": self.certified,
            "predicted_authority": self.predicted_authority,
            "labeled_records": self.labeled_records,
            "prequential_records": self.prequential_records,
        }


@dataclass(frozen=True)
class TargetGroundedProjection:
    """Best action in the scalar family anchored by the last Target action."""

    optimal_authority: float
    normalized_innovation: tuple[float, ...]
    innovation_l2: float


@dataclass(frozen=True)
class TargetGroundedReuseError:
    """Observed error of the reuse action the online policy would execute."""

    authority: float
    normalized_error: tuple[float, ...]
    error_l2: float


def evaluate_target_grounded_reuse(
    anchor_action: Sequence[float],
    target_action: Sequence[float],
    action_scale: Sequence[float],
    *,
    authority: float,
    scaled_dimensions: int = 6,
) -> TargetGroundedReuseError:
    """Score the deployed reuse action after Target reveals its correction."""

    anchor = np.asarray(anchor_action, dtype=np.float64).reshape(-1)
    target = np.asarray(target_action, dtype=np.float64).reshape(-1)
    scale = np.asarray(action_scale, dtype=np.float64).reshape(-1)
    if anchor.shape != target.shape or anchor.shape != scale.shape:
        raise ValueError("anchor_action, target_action, and action_scale must align.")
    if not 1 <= int(scaled_dimensions) <= anchor.size:
        raise ValueError("scaled_dimensions must lie within the action vector.")
    if np.any(~np.isfinite(anchor)) or np.any(~np.isfinite(target)):
        raise ValueError("Action vectors must be finite.")
    if np.any(~np.isfinite(scale)) or np.any(scale <= 0.0):
        raise ValueError("action_scale must be finite and strictly positive.")
    retained_authority = float(authority)
    if not math.isfinite(retained_authority):
        raise ValueError("authority must be finite.")
    retained_authority = float(np.clip(retained_authority, 0.0, 1.0))

    reused = anchor.copy()
    reused[: int(scaled_dimensions)] *= retained_authority
    normalized_error = (target - reused) / scale
    return TargetGroundedReuseError(
        authority=retained_authority,
        normalized_error=tuple(float(value) for value in normalized_error),
        error_l2=float(np.linalg.norm(normalized_error)),
    )


def project_target_onto_anchor(
    anchor_action: Sequence[float],
    target_action: Sequence[float],
    action_scale: Sequence[float],
    *,
    scaled_dimensions: int = 6,
) -> TargetGroundedProjection:
    """Project a Target action onto a direction-preserving reuse family.

    The first ``scaled_dimensions`` coordinates share one scalar authority.
    Remaining coordinates, such as a binary gripper command, are reused
    exactly and therefore remain in the irreducible innovation label.
    """

    anchor = np.asarray(anchor_action, dtype=np.float64).reshape(-1)
    target = np.asarray(target_action, dtype=np.float64).reshape(-1)
    scale = np.asarray(action_scale, dtype=np.float64).reshape(-1)
    if anchor.shape != target.shape or anchor.shape != scale.shape:
        raise ValueError("anchor_action, target_action, and action_scale must align.")
    if not 1 <= int(scaled_dimensions) <= anchor.size:
        raise ValueError("scaled_dimensions must lie within the action vector.")
    if np.any(~np.isfinite(anchor)) or np.any(~np.isfinite(target)):
        raise ValueError("Action vectors must be finite.")
    if np.any(~np.isfinite(scale)) or np.any(scale <= 0.0):
        raise ValueError("action_scale must be finite and strictly positive.")

    controlled = int(scaled_dimensions)
    normalized_anchor = anchor / scale
    normalized_target = target / scale
    anchor_direction = normalized_anchor[:controlled]
    target_direction = normalized_target[:controlled]
    anchor_energy = float(anchor_direction @ anchor_direction)
    authority = float(
        np.clip(
            float(anchor_direction @ target_direction) / max(anchor_energy, 1e-12),
            0.0,
            1.0,
        )
    )
    innovation = normalized_target - normalized_anchor
    innovation[:controlled] = target_direction - authority * anchor_direction
    return TargetGroundedProjection(
        optimal_authority=authority,
        normalized_innovation=tuple(float(value) for value in innovation),
        innovation_l2=float(np.linalg.norm(innovation)),
    )


class OnlineRevealingRiskModel:
    """Robust online linear-UCB model for hypothetical hold correction.

    The model is refit from a bounded memory only when a Target call reveals a
    new label. Hold decisions reuse the cached posterior, keeping their CPU
    overhead independent of memory size.
    """

    def __init__(
        self,
        feature_names: Sequence[str],
        *,
        confidence_scale: float = 1.0,
        ridge: float = 1.0,
        max_records: int = 512,
        min_records: int | None = None,
    ) -> None:
        self.feature_names = tuple(str(name) for name in feature_names)
        if not self.feature_names:
            raise ValueError("feature_names must not be empty.")
        self.confidence_scale = float(confidence_scale)
        self.ridge = float(ridge)
        self.max_records = int(max_records)
        self.min_records = int(
            len(self.feature_names) + 2 if min_records is None else min_records
        )
        if self.confidence_scale < 0.0 or not math.isfinite(self.confidence_scale):
            raise ValueError("confidence_scale must be finite and non-negative.")
        if self.ridge <= 0.0 or not math.isfinite(self.ridge):
            raise ValueError("ridge must be finite and positive.")
        if self.max_records < 2:
            raise ValueError("max_records must be at least two.")
        if self.min_records < 2:
            raise ValueError("min_records must be at least two.")
        self.reset()

    def reset(self) -> None:
        self._contexts: list[np.ndarray] = []
        self._corrections: list[float] = []
        self._fit_cache = None

    @property
    def labeled_records(self) -> int:
        return len(self._corrections)

    @property
    def ready(self) -> bool:
        return self.labeled_records >= self.min_records

    def vectorize(self, features: Mapping[str, float]) -> np.ndarray:
        missing = [name for name in self.feature_names if name not in features]
        if missing:
            raise ValueError(f"Missing revealing-action features: {missing}")
        vector = np.asarray(
            [features[name] for name in self.feature_names], dtype=np.float64
        )
        if np.any(~np.isfinite(vector)):
            raise ValueError("Revealing-action features must be finite.")
        return vector

    def observe(self, features: Mapping[str, float], correction_l2: float) -> None:
        correction = float(correction_l2)
        if correction < 0.0 or not math.isfinite(correction):
            raise ValueError("correction_l2 must be finite and non-negative.")
        self._contexts.append(self.vectorize(features))
        self._corrections.append(correction)
        overflow = self.labeled_records - self.max_records
        if overflow > 0:
            del self._contexts[:overflow]
            del self._corrections[:overflow]
        self._refit()

    @staticmethod
    def _robust_location_scale(contexts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        median = np.median(contexts, axis=0)
        absolute_deviation = np.median(np.abs(contexts - median), axis=0)
        robust_scale = 1.4826 * absolute_deviation
        standard_scale = np.std(contexts, axis=0)
        scale = np.where(robust_scale > 1e-8, robust_scale, standard_scale)
        scale = np.where(scale > 1e-8, scale, 1.0)
        return median, scale

    @staticmethod
    def _robust_coordinates(
        contexts: np.ndarray, query: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        median, scale = OnlineRevealingRiskModel._robust_location_scale(contexts)
        normalized_contexts = np.clip((contexts - median) / scale, -8.0, 8.0)
        normalized_query = np.clip((query - median) / scale, -8.0, 8.0)
        return normalized_contexts, normalized_query

    def _refit(self) -> None:
        count = self.labeled_records
        if count == 0:
            self._fit_cache = None
            return
        contexts = np.stack(self._contexts)
        corrections = np.asarray(self._corrections, dtype=np.float64)
        median, scale = self._robust_location_scale(contexts)
        normalized_contexts = np.clip((contexts - median) / scale, -8.0, 8.0)
        design = np.concatenate(
            [np.ones((count, 1), dtype=np.float64), normalized_contexts], axis=1
        )
        regularizer = np.eye(design.shape[1], dtype=np.float64) * self.ridge
        regularizer[0, 0] = 1e-8
        precision = design.T @ design + regularizer
        coefficients = np.linalg.solve(precision, design.T @ corrections)
        precision_inverse = np.linalg.solve(
            precision, np.eye(precision.shape[0], dtype=np.float64)
        )
        residual = corrections - design @ coefficients
        degrees_of_freedom = max(count - design.shape[1], 1)
        residual_scale = float(
            math.sqrt(max(float(residual @ residual) / degrees_of_freedom, 1e-10))
        )
        self._fit_cache = {
            "median": median,
            "scale": scale,
            "coefficients": coefficients,
            "precision_inverse": precision_inverse,
            "residual_scale": residual_scale,
            "sorted_corrections": np.sort(corrections),
        }

    def estimate(self, features: Mapping[str, float]) -> RevealingRiskEstimate:
        query = self.vectorize(features)
        count = self.labeled_records
        dimension = len(self.feature_names)
        if count == 0:
            return RevealingRiskEstimate(
                ready=False,
                predicted_correction=0.0,
                epistemic_uncertainty=0.0,
                upper_confidence_risk=0.0,
                risk_percentile=1.0,
                labeled_records=0,
                feature_dimension=dimension,
            )

        cache = self._fit_cache
        normalized_query = np.clip(
            (query - cache["median"]) / cache["scale"], -8.0, 8.0
        )
        query_design = np.concatenate(
            [np.ones(1, dtype=np.float64), normalized_query]
        )
        predicted = float(max(0.0, query_design @ cache["coefficients"]))
        leverage_squared = float(
            query_design @ cache["precision_inverse"] @ query_design
        )
        leverage = math.sqrt(max(leverage_squared, 0.0))
        uncertainty = cache["residual_scale"] * math.sqrt(1.0 + leverage * leverage)
        upper = max(0.0, predicted + self.confidence_scale * uncertainty)
        percentile = float(
            np.searchsorted(cache["sorted_corrections"], upper, side="right") / count
        )
        return RevealingRiskEstimate(
            ready=self.ready,
            predicted_correction=predicted,
            epistemic_uncertainty=uncertainty,
            upper_confidence_risk=upper,
            risk_percentile=percentile,
            labeled_records=count,
            feature_dimension=dimension,
        )


class OnlineLocalRevealingRiskModel:
    """Non-parametric UCB risk memory for target-revealed contexts.

    A local model avoids extrapolating a global linear trend into unseen hold
    depths.  Its confidence bound grows with both local target variability and
    distance from the nearest revealed context, so an unfamiliar state causes
    re-grounding until Target feedback establishes a recoverable neighborhood.
    """

    def __init__(
        self,
        feature_names: Sequence[str],
        *,
        confidence_scale: float = 1.0,
        max_records: int = 512,
        min_records: int | None = None,
        max_neighbors: int = 32,
    ) -> None:
        self.feature_names = tuple(str(name) for name in feature_names)
        if not self.feature_names:
            raise ValueError("feature_names must not be empty.")
        self.confidence_scale = float(confidence_scale)
        self.max_records = int(max_records)
        self.min_records = int(
            len(self.feature_names) + 2 if min_records is None else min_records
        )
        self.max_neighbors = int(max_neighbors)
        if self.confidence_scale < 0.0 or not math.isfinite(self.confidence_scale):
            raise ValueError("confidence_scale must be finite and non-negative.")
        if self.max_records < 2 or self.min_records < 2:
            raise ValueError("record limits must be at least two.")
        if self.max_neighbors < 2:
            raise ValueError("max_neighbors must be at least two.")
        self.reset()

    def reset(self) -> None:
        self._contexts: list[np.ndarray] = []
        self._corrections: list[float] = []

    @property
    def labeled_records(self) -> int:
        return len(self._corrections)

    @property
    def ready(self) -> bool:
        return self.labeled_records >= self.min_records

    def vectorize(self, features: Mapping[str, float]) -> np.ndarray:
        missing = [name for name in self.feature_names if name not in features]
        if missing:
            raise ValueError(f"Missing revealing-action features: {missing}")
        vector = np.asarray(
            [features[name] for name in self.feature_names], dtype=np.float64
        )
        if np.any(~np.isfinite(vector)):
            raise ValueError("Revealing-action features must be finite.")
        return vector

    def observe(self, features: Mapping[str, float], correction_l2: float) -> None:
        correction = float(correction_l2)
        if correction < 0.0 or not math.isfinite(correction):
            raise ValueError("correction_l2 must be finite and non-negative.")
        self._contexts.append(self.vectorize(features))
        self._corrections.append(correction)
        overflow = self.labeled_records - self.max_records
        if overflow > 0:
            del self._contexts[:overflow]
            del self._corrections[:overflow]

    def estimate(self, features: Mapping[str, float]) -> RevealingRiskEstimate:
        query = self.vectorize(features)
        count = self.labeled_records
        dimension = len(self.feature_names)
        if count == 0:
            return RevealingRiskEstimate(
                ready=False,
                predicted_correction=0.0,
                epistemic_uncertainty=0.0,
                upper_confidence_risk=0.0,
                risk_percentile=1.0,
                labeled_records=0,
                feature_dimension=dimension,
            )

        contexts = np.stack(self._contexts)
        corrections = np.asarray(self._corrections, dtype=np.float64)
        normalized_contexts, normalized_query = (
            OnlineRevealingRiskModel._robust_coordinates(contexts, query)
        )
        distances = np.linalg.norm(
            normalized_contexts - normalized_query[None, :], axis=1
        ) / math.sqrt(dimension)
        neighbor_count = min(
            count,
            self.max_neighbors,
            max(4, int(math.ceil(math.sqrt(count)))),
        )
        neighbor_indices = np.argpartition(
            distances, neighbor_count - 1
        )[:neighbor_count]
        neighbor_distances = distances[neighbor_indices]
        neighbor_corrections = corrections[neighbor_indices]
        bandwidth = max(float(np.max(neighbor_distances)), 1e-6)
        weights = np.exp(-0.5 * np.square(neighbor_distances / bandwidth))
        weight_sum = max(float(np.sum(weights)), 1e-12)
        predicted = float(np.sum(weights * neighbor_corrections) / weight_sum)
        centered = neighbor_corrections - predicted
        local_variance = float(np.sum(weights * centered * centered) / weight_sum)
        effective_count = float(weight_sum * weight_sum / np.sum(weights * weights))

        label_median = float(np.median(corrections))
        label_mad = float(np.median(np.abs(corrections - label_median)))
        global_scale = max(1.4826 * label_mad, float(np.std(corrections)), 1e-6)
        local_standard_error = math.sqrt(max(local_variance, 0.0)) / math.sqrt(
            max(effective_count, 1.0)
        )
        novelty = global_scale * float(np.min(neighbor_distances))
        uncertainty = local_standard_error + novelty
        upper = max(0.0, predicted + self.confidence_scale * uncertainty)
        percentile = float(
            np.searchsorted(np.sort(corrections), upper, side="right") / count
        )
        return RevealingRiskEstimate(
            ready=self.ready,
            predicted_correction=predicted,
            epistemic_uncertainty=uncertainty,
            upper_confidence_risk=upper,
            risk_percentile=percentile,
            labeled_records=count,
            feature_dimension=dimension,
        )


@dataclass(frozen=True)
class VTPFUtilityEstimate:
    """Online estimate of whether temporal prefill avoids a tail verification."""

    ready: bool
    full_match_probability: float
    epistemic_uncertainty: float
    expected_target_forwards: float
    labeled_records: int

    def as_record(self) -> dict:
        return {
            "ready": self.ready,
            "full_match_probability": self.full_match_probability,
            "epistemic_uncertainty": self.epistemic_uncertainty,
            "expected_target_forwards": self.expected_target_forwards,
            "labeled_records": self.labeled_records,
        }


class OnlineVTPFUtilityModel:
    """Learn the compute utility of temporal prefill from every Target action.

    A normal Target action reveals the final exact action as well, so the label
    is available regardless of which prefill route was selected.  The compute
    proxy counts one mandatory multimodal prefill and one possible tail verify;
    a complete VTPF match removes the latter.
    """

    def __init__(
        self,
        feature_names: Sequence[str],
        *,
        max_records: int = 512,
        min_records: int | None = None,
        max_neighbors: int = 32,
    ) -> None:
        self._model = OnlineLocalRevealingRiskModel(
            feature_names,
            confidence_scale=0.0,
            max_records=max_records,
            min_records=min_records,
            max_neighbors=max_neighbors,
        )

    @property
    def labeled_records(self) -> int:
        return self._model.labeled_records

    @property
    def ready(self) -> bool:
        return self._model.ready

    def observe(self, features: Mapping[str, float], *, full_match: bool) -> None:
        self._model.observe(features, float(bool(full_match)))

    def estimate(self, features: Mapping[str, float]) -> VTPFUtilityEstimate:
        estimate = self._model.estimate(features)
        probability = float(np.clip(estimate.predicted_correction, 0.0, 1.0))
        return VTPFUtilityEstimate(
            ready=estimate.ready,
            full_match_probability=probability,
            epistemic_uncertainty=estimate.epistemic_uncertainty,
            expected_target_forwards=2.0 - probability,
            labeled_records=estimate.labeled_records,
        )


def cost_aware_revealing_priority(
    risk_percentile: float,
    utility: VTPFUtilityEstimate | None,
) -> float:
    """Rank Target calls by expected correction benefit per Target forward."""

    risk = float(risk_percentile)
    if not math.isfinite(risk) or not 0.0 <= risk <= 1.0:
        raise ValueError("risk_percentile must lie in [0, 1].")
    expected_forwards = (
        utility.expected_target_forwards
        if utility is not None and utility.ready
        else 2.0
    )
    # Normalize by the worst-case two-forward target route.  Before the utility
    # model is ready this exactly recovers the original risk ordering.
    return min(1.0, 2.0 * risk / expected_forwards)


@dataclass(frozen=True)
class TransitionSurpriseEstimate:
    """Strictly prequential surprise from the online dynamics observer."""

    ready: bool
    surprise: float
    epistemic_uncertainty: float
    upper_confidence_surprise: float
    surprise_percentile: float
    observed_transitions: int

    def as_record(self) -> dict:
        return {
            "ready": self.ready,
            "surprise": self.surprise,
            "epistemic_uncertainty": self.epistemic_uncertainty,
            "upper_confidence_surprise": self.upper_confidence_surprise,
            "surprise_percentile": self.surprise_percentile,
            "observed_transitions": self.observed_transitions,
        }


class OnlineTransitionObserver:
    """Learn one-step robot dynamics from every executed control step.

    The observer predicts the next proprioceptive delta before seeing it.  The
    resulting prequential error is available after both held and Target actions,
    providing dense self-supervision for event-triggered re-grounding.
    """

    def __init__(
        self,
        *,
        state_dimension: int = 6,
        action_dimension: int = 6,
        confidence_scale: float = 1.0,
        ridge: float = 1.0,
        max_records: int = 512,
        min_records: int | None = None,
    ) -> None:
        self.state_dimension = int(state_dimension)
        self.action_dimension = int(action_dimension)
        self.confidence_scale = float(confidence_scale)
        self.ridge = float(ridge)
        self.max_records = int(max_records)
        input_dimension = self.state_dimension + self.action_dimension
        self.min_records = int(
            input_dimension + 2 if min_records is None else min_records
        )
        if self.state_dimension < 1 or self.action_dimension < 1:
            raise ValueError("state and action dimensions must be positive.")
        if self.confidence_scale < 0.0 or not math.isfinite(self.confidence_scale):
            raise ValueError("confidence_scale must be finite and non-negative.")
        if self.ridge <= 0.0 or not math.isfinite(self.ridge):
            raise ValueError("ridge must be finite and positive.")
        if self.max_records < 2 or self.min_records < 2:
            raise ValueError("record limits must be at least two.")
        self.reset()

    def reset(self) -> None:
        self._inputs: list[np.ndarray] = []
        self._deltas: list[np.ndarray] = []
        self._prequential_surprises: list[float] = []
        self._fit_cache = None
        self.reset_episode()

    def reset_episode(self) -> None:
        self._pending_state = None
        self._pending_action = None

    @property
    def observed_transitions(self) -> int:
        return len(self._deltas)

    @property
    def ready(self) -> bool:
        return self.observed_transitions >= self.min_records

    def _state(self, value: Sequence[float]) -> np.ndarray:
        vector = np.asarray(value, dtype=np.float64).reshape(-1)
        if vector.size < self.state_dimension:
            raise ValueError("state has fewer dimensions than configured.")
        vector = vector[: self.state_dimension]
        if np.any(~np.isfinite(vector)):
            raise ValueError("state must be finite.")
        return vector

    def _action(self, value: Sequence[float]) -> np.ndarray:
        vector = np.asarray(value, dtype=np.float64).reshape(-1)
        if vector.size < self.action_dimension:
            raise ValueError("action has fewer dimensions than configured.")
        vector = vector[: self.action_dimension]
        if np.any(~np.isfinite(vector)):
            raise ValueError("action must be finite.")
        return vector

    def stage(self, state: Sequence[float], action: Sequence[float]) -> None:
        self._pending_state = self._state(state).copy()
        self._pending_action = self._action(action).copy()

    def observe(self, current_state: Sequence[float]) -> TransitionSurpriseEstimate:
        current = self._state(current_state)
        count = self.observed_transitions
        if self._pending_state is None or self._pending_action is None:
            return TransitionSurpriseEstimate(
                ready=False,
                surprise=0.0,
                epistemic_uncertainty=0.0,
                upper_confidence_surprise=0.0,
                surprise_percentile=1.0,
                observed_transitions=count,
            )

        model_input = np.concatenate(
            [self._pending_state, self._pending_action]
        )
        observed_delta = current - self._pending_state
        ready_before = self.ready and self._fit_cache is not None
        surprise = 0.0
        uncertainty = 0.0
        upper = 0.0
        percentile = 1.0
        if self._fit_cache is not None:
            cache = self._fit_cache
            normalized_input = np.clip(
                (model_input - cache["input_median"]) / cache["input_scale"],
                -8.0,
                8.0,
            )
            design = np.concatenate([np.ones(1), normalized_input])
            predicted_delta = design @ cache["coefficients"]
            normalized_error = (
                observed_delta - predicted_delta
            ) / cache["delta_scale"]
            surprise = float(
                np.linalg.norm(normalized_error) / math.sqrt(self.state_dimension)
            )
            leverage_squared = float(
                design @ cache["precision_inverse"] @ design
            )
            uncertainty = float(
                cache["residual_scale"]
                * math.sqrt(1.0 + max(leverage_squared, 0.0))
            )
            upper = max(
                0.0,
                surprise + self.confidence_scale * uncertainty,
            )
            if self._prequential_surprises:
                percentile = float(
                    np.searchsorted(
                        np.sort(self._prequential_surprises), upper, side="right"
                    )
                    / len(self._prequential_surprises)
                )

        self._inputs.append(model_input)
        self._deltas.append(observed_delta)
        if ready_before:
            self._prequential_surprises.append(surprise)
        overflow = self.observed_transitions - self.max_records
        if overflow > 0:
            del self._inputs[:overflow]
            del self._deltas[:overflow]
        surprise_overflow = len(self._prequential_surprises) - self.max_records
        if surprise_overflow > 0:
            del self._prequential_surprises[:surprise_overflow]
        self._refit()
        return TransitionSurpriseEstimate(
            ready=ready_before,
            surprise=surprise,
            epistemic_uncertainty=uncertainty,
            upper_confidence_surprise=upper,
            surprise_percentile=percentile if ready_before else 1.0,
            observed_transitions=count + 1,
        )

    def _refit(self) -> None:
        count = self.observed_transitions
        if count < 2:
            self._fit_cache = None
            return
        inputs = np.stack(self._inputs)
        deltas = np.stack(self._deltas)
        input_median, input_scale = OnlineRevealingRiskModel._robust_location_scale(
            inputs
        )
        delta_median, delta_scale = OnlineRevealingRiskModel._robust_location_scale(
            deltas
        )
        del delta_median
        normalized_inputs = np.clip(
            (inputs - input_median) / input_scale, -8.0, 8.0
        )
        design = np.concatenate(
            [np.ones((count, 1), dtype=np.float64), normalized_inputs], axis=1
        )
        regularizer = np.eye(design.shape[1], dtype=np.float64) * self.ridge
        regularizer[0, 0] = 1e-8
        precision = design.T @ design + regularizer
        coefficients = np.linalg.solve(precision, design.T @ deltas)
        prediction_error = (deltas - design @ coefficients) / delta_scale
        residual_scale = float(
            math.sqrt(
                max(
                    float(np.mean(np.square(prediction_error))),
                    1e-10,
                )
            )
        )
        self._fit_cache = {
            "input_median": input_median,
            "input_scale": input_scale,
            "delta_scale": delta_scale,
            "coefficients": coefficients,
            "precision_inverse": np.linalg.solve(
                precision, np.eye(precision.shape[0], dtype=np.float64)
            ),
            "residual_scale": residual_scale,
        }


class OnlineRevealingResidualModel:
    """Learn how a target action would correct a held action.

    Only target invocations provide labels.  Correction authority is estimated
    from strictly prequential predictions: a prediction must be made before its
    target residual is revealed.  Consequently, the model starts with zero
    authority and can affect held actions only after demonstrating out-of-sample
    error reduction online.
    """

    def __init__(
        self,
        feature_names: Sequence[str],
        *,
        action_dimension: int = 6,
        ridge: float = 1.0,
        authority_ridge: float = 1e-3,
        max_records: int = 512,
        min_records: int | None = None,
    ) -> None:
        self.feature_names = tuple(str(name) for name in feature_names)
        self.action_dimension = int(action_dimension)
        self.ridge = float(ridge)
        self.authority_ridge = float(authority_ridge)
        self.max_records = int(max_records)
        self.min_records = int(
            len(self.feature_names) + 2 if min_records is None else min_records
        )
        if not self.feature_names:
            raise ValueError("feature_names must not be empty.")
        if self.action_dimension < 1:
            raise ValueError("action_dimension must be positive.")
        if self.ridge <= 0.0 or self.authority_ridge <= 0.0:
            raise ValueError("ridge values must be positive.")
        if self.max_records < 2 or self.min_records < 2:
            raise ValueError("record limits must be at least two.")
        self.reset()

    def reset(self) -> None:
        self._contexts: list[np.ndarray] = []
        self._residuals: list[np.ndarray] = []
        self._fit_cache = None
        self._authority_numerator = 0.0
        self._authority_denominator = 0.0
        self._prequential_records = 0
        self._prequential_baseline_sse = 0.0
        self._prequential_corrected_sse = 0.0

    @property
    def labeled_records(self) -> int:
        return len(self._residuals)

    @property
    def ready(self) -> bool:
        return self.labeled_records >= self.min_records

    @property
    def learned_authority(self) -> float:
        value = self._authority_numerator / (
            self._authority_denominator + self.authority_ridge
        )
        return float(np.clip(value, 0.0, 1.0))

    @property
    def prequential_records(self) -> int:
        return self._prequential_records

    @property
    def prequential_improvement(self) -> float | None:
        if self._prequential_records == 0 or self._prequential_baseline_sse <= 0.0:
            return None
        return float(
            1.0
            - self._prequential_corrected_sse / self._prequential_baseline_sse
        )

    def vectorize(self, features: Mapping[str, float]) -> np.ndarray:
        missing = [name for name in self.feature_names if name not in features]
        if missing:
            raise ValueError(f"Missing revealing-action features: {missing}")
        vector = np.asarray(
            [features[name] for name in self.feature_names], dtype=np.float64
        )
        if np.any(~np.isfinite(vector)):
            raise ValueError("Revealing-action features must be finite.")
        return vector

    def estimate(self, features: Mapping[str, float]) -> RevealingResidualEstimate:
        query = self.vectorize(features)
        count = self.labeled_records
        predicted = np.zeros(self.action_dimension, dtype=np.float64)
        if count >= 2 and self._fit_cache is not None:
            cache = self._fit_cache
            normalized_query = np.clip(
                (query - cache["median"]) / cache["scale"], -8.0, 8.0
            )
            query_design = np.concatenate(
                [np.ones(1, dtype=np.float64), normalized_query]
            )
            predicted = query_design @ cache["coefficients"]
        authority = self.learned_authority if self.ready else 0.0
        return RevealingResidualEstimate(
            ready=self.ready,
            predicted_residual=tuple(float(value) for value in predicted),
            predicted_residual_l2=float(np.linalg.norm(predicted)),
            learned_authority=authority,
            labeled_records=count,
            prequential_records=self.prequential_records,
        )

    def observe(
        self,
        features: Mapping[str, float],
        residual: Sequence[float],
        *,
        prequential_prediction: Sequence[float] | None = None,
        prequential_ready: bool = False,
    ) -> dict:
        residual_vector = np.asarray(residual, dtype=np.float64).reshape(-1)
        if residual_vector.shape != (self.action_dimension,):
            raise ValueError(
                f"residual must have shape ({self.action_dimension},)."
            )
        if np.any(~np.isfinite(residual_vector)):
            raise ValueError("residual must be finite.")

        shadow_record = {
            "prequential_ready": bool(prequential_ready),
            "authority_before": self.learned_authority,
            "baseline_squared_error": None,
            "corrected_squared_error": None,
        }
        if prequential_prediction is not None and prequential_ready:
            prediction = np.asarray(
                prequential_prediction, dtype=np.float64
            ).reshape(-1)
            if prediction.shape != residual_vector.shape:
                raise ValueError("prequential_prediction has the wrong shape.")
            authority_before = self.learned_authority
            baseline_sse = float(residual_vector @ residual_vector)
            corrected_error = residual_vector - authority_before * prediction
            corrected_sse = float(corrected_error @ corrected_error)
            self._prequential_baseline_sse += baseline_sse
            self._prequential_corrected_sse += corrected_sse
            self._prequential_records += 1
            self._authority_numerator += float(prediction @ residual_vector)
            self._authority_denominator += float(prediction @ prediction)
            shadow_record.update(
                {
                    "baseline_squared_error": baseline_sse,
                    "corrected_squared_error": corrected_sse,
                }
            )

        self._contexts.append(self.vectorize(features))
        self._residuals.append(residual_vector.copy())
        overflow = self.labeled_records - self.max_records
        if overflow > 0:
            del self._contexts[:overflow]
            del self._residuals[:overflow]
        self._refit()
        shadow_record.update(
            {
                "authority_after": self.learned_authority,
                "prequential_records": self.prequential_records,
                "prequential_improvement": self.prequential_improvement,
                "labeled_records": self.labeled_records,
            }
        )
        return shadow_record

    def _refit(self) -> None:
        count = self.labeled_records
        if count < 2:
            self._fit_cache = None
            return
        contexts = np.stack(self._contexts)
        residuals = np.stack(self._residuals)
        median, scale = OnlineRevealingRiskModel._robust_location_scale(contexts)
        normalized_contexts = np.clip((contexts - median) / scale, -8.0, 8.0)
        design = np.concatenate(
            [np.ones((count, 1), dtype=np.float64), normalized_contexts], axis=1
        )
        regularizer = np.eye(design.shape[1], dtype=np.float64) * self.ridge
        regularizer[0, 0] = 1e-8
        precision = design.T @ design + regularizer
        self._fit_cache = {
            "median": median,
            "scale": scale,
            "coefficients": np.linalg.solve(precision, design.T @ residuals),
        }


class OnlineRevealingAuthorityModel:
    """Predict a scalar authority for the last target-grounded action.

    The target label is the bounded least-squares projection of the current
    target action onto the previous target action.  Unlike a free residual
    vector, this model cannot invent a new control direction.
    """

    def __init__(
        self,
        feature_names: Sequence[str],
        *,
        ridge: float = 1.0,
        max_records: int = 512,
        min_records: int | None = None,
    ) -> None:
        self.feature_names = tuple(str(name) for name in feature_names)
        self.ridge = float(ridge)
        self.max_records = int(max_records)
        self.min_records = int(
            len(self.feature_names) + 2 if min_records is None else min_records
        )
        if not self.feature_names:
            raise ValueError("feature_names must not be empty.")
        if self.ridge <= 0.0:
            raise ValueError("ridge must be positive.")
        self.reset()

    def reset(self) -> None:
        self._contexts: list[np.ndarray] = []
        self._authorities: list[float] = []
        self._fit_cache = None
        self._prequential_records = 0
        self._prequential_baseline_sse = 0.0
        self._prequential_predicted_sse = 0.0

    @property
    def labeled_records(self) -> int:
        return len(self._authorities)

    @property
    def ready(self) -> bool:
        return self.labeled_records >= self.min_records

    @property
    def prequential_records(self) -> int:
        return self._prequential_records

    @property
    def prequential_improvement(self) -> float | None:
        if self._prequential_records == 0 or self._prequential_baseline_sse <= 0.0:
            return None
        return float(
            1.0
            - self._prequential_predicted_sse / self._prequential_baseline_sse
        )

    def vectorize(self, features: Mapping[str, float]) -> np.ndarray:
        missing = [name for name in self.feature_names if name not in features]
        if missing:
            raise ValueError(f"Missing revealing-action features: {missing}")
        vector = np.asarray(
            [features[name] for name in self.feature_names], dtype=np.float64
        )
        if np.any(~np.isfinite(vector)):
            raise ValueError("Revealing-action features must be finite.")
        return vector

    def estimate(self, features: Mapping[str, float]) -> RevealingAuthorityEstimate:
        query = self.vectorize(features)
        predicted = 0.0
        if self._fit_cache is not None:
            cache = self._fit_cache
            normalized = np.clip(
                (query - cache["median"]) / cache["scale"], -8.0, 8.0
            )
            predicted = float(
                np.clip(
                    np.concatenate([np.ones(1), normalized])
                    @ cache["coefficients"],
                    0.0,
                    1.0,
                )
            )
        return RevealingAuthorityEstimate(
            ready=self.ready,
            certified=bool(
                self.ready
                and self.prequential_improvement is not None
                and self.prequential_improvement > 0.0
            ),
            predicted_authority=predicted,
            labeled_records=self.labeled_records,
            prequential_records=self.prequential_records,
        )

    def observe(
        self,
        features: Mapping[str, float],
        optimal_authority: float,
        *,
        prequential_prediction: float | None = None,
        prequential_ready: bool = False,
        baseline_squared_error: float | None = None,
        predicted_squared_error: float | None = None,
    ) -> dict:
        authority = float(np.clip(optimal_authority, 0.0, 1.0))
        if prequential_ready:
            if baseline_squared_error is None or predicted_squared_error is None:
                raise ValueError("Prequential authority feedback requires both errors.")
            self._prequential_records += 1
            self._prequential_baseline_sse += float(baseline_squared_error)
            self._prequential_predicted_sse += float(predicted_squared_error)
        self._contexts.append(self.vectorize(features))
        self._authorities.append(authority)
        overflow = self.labeled_records - self.max_records
        if overflow > 0:
            del self._contexts[:overflow]
            del self._authorities[:overflow]
        self._refit()
        return {
            "optimal_authority": authority,
            "prequential_prediction": prequential_prediction,
            "prequential_ready": bool(prequential_ready),
            "baseline_squared_error": baseline_squared_error,
            "predicted_squared_error": predicted_squared_error,
            "prequential_records": self.prequential_records,
            "prequential_improvement": self.prequential_improvement,
            "labeled_records": self.labeled_records,
        }

    def _refit(self) -> None:
        count = self.labeled_records
        if count < 2:
            self._fit_cache = None
            return
        contexts = np.stack(self._contexts)
        labels = np.asarray(self._authorities, dtype=np.float64)
        median, scale = OnlineRevealingRiskModel._robust_location_scale(contexts)
        normalized = np.clip((contexts - median) / scale, -8.0, 8.0)
        design = np.concatenate(
            [np.ones((count, 1), dtype=np.float64), normalized], axis=1
        )
        regularizer = np.eye(design.shape[1], dtype=np.float64) * self.ridge
        regularizer[0, 0] = 1e-8
        precision = design.T @ design + regularizer
        self._fit_cache = {
            "median": median,
            "scale": scale,
            "coefficients": np.linalg.solve(precision, design.T @ labels),
        }


class OnlineTargetBudgetAllocator:
    """Allocate target calls over all control steps, not over a fixed cadence."""

    def __init__(self, desired_target_density: float) -> None:
        density = float(desired_target_density)
        if not 1.0 / 3.0 <= density <= 1.0:
            raise ValueError("desired_target_density must lie in [1/3, 1].")
        self.desired_target_density = density
        self.desired_hold_fraction = 1.0 - density
        self.reset()

    def reset(self) -> None:
        self.hold_threshold = self.desired_hold_fraction
        self.decision_count = 0
        self.hold_count = 0
        self.target_count = 0

    def decide(
        self,
        risk_percentile: float,
        *,
        eligible: bool,
        model_ready: bool,
    ) -> RevealingBudgetDecision:
        risk = float(risk_percentile)
        if not 0.0 <= risk <= 1.0 or not math.isfinite(risk):
            raise ValueError("risk_percentile must be finite and lie in [0, 1].")
        threshold_before = self.hold_threshold
        if not eligible:
            allow = False
            reason = "target_required"
        elif not model_ready:
            allow = False
            reason = "risk_model_warmup"
        else:
            allow = risk <= threshold_before
            reason = "contextual_hold" if allow else "contextual_target"

        self.decision_count += 1
        self.hold_count += int(allow)
        self.target_count += int(not allow)
        # Warm-up Target calls create the first labels; treating them as budget
        # debt would trigger an unsafe burst of compensating holds precisely
        # when the posterior has the least evidence.
        if model_ready:
            step_size = self.decision_count ** -0.5
            self.hold_threshold = min(
                1.0,
                max(
                    0.0,
                    threshold_before
                    + step_size * (self.desired_hold_fraction - float(allow)),
                ),
            )
        else:
            step_size = 0.0
        return RevealingBudgetDecision(
            allow_hold=allow,
            reason=reason,
            risk_percentile=risk,
            threshold_before=threshold_before,
            threshold_after=self.hold_threshold,
            desired_target_density=self.desired_target_density,
            decision_count=self.decision_count,
            hold_count=self.hold_count,
            target_count=self.target_count,
            step_size=step_size,
        )
