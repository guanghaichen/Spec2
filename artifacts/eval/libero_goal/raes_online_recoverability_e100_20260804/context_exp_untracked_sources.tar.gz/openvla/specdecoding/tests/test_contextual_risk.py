from __future__ import annotations

import numpy as np
import pytest

from openvla.specdecoding.model.contextual_risk import (
    ContextualRiskMemory,
    OnlineBudgetAllocator,
    extension_fraction_from_target_density,
)


def _profile() -> dict:
    contexts = [[value, value] for value in np.linspace(0.0, 1.0, 25)]
    corrections = list(np.linspace(0.0, 1.0, 25))
    return {
        "schema_version": 1,
        "task_suite_name": "libero_goal",
        "feature_names": ["visual", "state"],
        "robust_median": [0.0, 0.0],
        "robust_scale": [1.0, 1.0],
        "normalized_contexts": contexts,
        "correction_l2": corrections,
        "risk_reference": corrections,
        "neighbors": 4,
        "local_risk_quantile": 0.75,
        "online_update": {"max_online_records": 2},
    }


def test_contextual_memory_ranks_low_and_high_drift() -> None:
    memory = ContextualRiskMemory(_profile())
    assert memory.risk_target == "inverse_age_correction"
    low = memory.estimate({"visual": 0.05, "state": 0.05})
    high = memory.estimate({"visual": 0.95, "state": 0.95})
    assert low.risk_target == "inverse_age_correction"
    assert low.as_record()["risk_target"] == low.risk_target
    assert low.correction_risk < high.correction_risk
    assert low.risk_percentile < high.risk_percentile
    memory.observe({"visual": 0.05, "state": 0.05}, correction_l2=0.9)
    assert memory.online_records == 1
    assert memory.estimate({"visual": 0.05, "state": 0.05}).correction_risk > low.correction_risk
    memory.observe({"visual": 0.1, "state": 0.1}, correction_l2=0.8)
    memory.observe({"visual": 0.2, "state": 0.2}, correction_l2=0.7)
    assert memory.online_records == 2


def test_contextual_memory_validates_risk_target() -> None:
    profile = _profile()
    profile["risk_target"] = "normalized_action_innovation"
    assert ContextualRiskMemory(profile).risk_target == profile["risk_target"]
    profile["risk_target"] = "unknown"
    with pytest.raises(ValueError, match="Unsupported contextual-risk target"):
        ContextualRiskMemory(profile)


def test_contextual_memory_supports_expected_correction_value() -> None:
    profile = _profile()
    profile["local_risk_statistic"] = "mean"
    memory = ContextualRiskMemory(profile)
    estimate = memory.estimate({"visual": 0.5, "state": 0.5})
    query = memory.vectorize({"visual": 0.5, "state": 0.5})
    contexts = np.asarray(profile["normalized_contexts"])
    ids = np.argsort(np.sum(np.square(contexts - query), axis=1))[:4]
    assert estimate.risk_statistic == "mean"
    assert estimate.correction_risk == pytest.approx(
        np.mean(np.asarray(profile["correction_l2"])[ids])
    )
    assert estimate.as_record()["risk_statistic"] == "mean"


def test_contextual_memory_rejects_unknown_risk_statistic() -> None:
    profile = _profile()
    profile["local_risk_statistic"] = "unknown"
    with pytest.raises(ValueError, match="Unsupported local-risk statistic"):
        ContextualRiskMemory(profile)


def test_online_allocator_tracks_budget_without_periodic_schedule() -> None:
    allocator = OnlineBudgetAllocator(0.48)
    rng = np.random.default_rng(7)
    decisions = [allocator.decide(value) for value in rng.uniform(size=500)]
    realized = sum(decision.allow for decision in decisions) / len(decisions)
    assert realized == pytest.approx(0.48, abs=0.015)
    assert any(decisions[index].allow != decisions[index + 1].allow for index in range(499))
    allocator.reset()
    assert allocator.candidate_count == 0
    assert allocator.selected_count == 0


def test_calibration_evidence_regularizes_early_dual_updates() -> None:
    allocator = OnlineBudgetAllocator(0.48, effective_prior_count=64)
    decision = allocator.decide(0.9)
    assert decision.allow is False
    assert decision.effective_prior_count == 64
    assert decision.step_size == pytest.approx(1.0 / np.sqrt(65.0))
    assert 0.48 < decision.dual_threshold_after < 1.0


def test_online_allocator_rejects_negative_prior_count() -> None:
    with pytest.raises(ValueError, match="effective_prior_count"):
        OnlineBudgetAllocator(0.48, effective_prior_count=-1)


def test_target_density_maps_to_extension_budget() -> None:
    assert extension_fraction_from_target_density(0.4) == pytest.approx(0.5)
    assert extension_fraction_from_target_density(0.5) == pytest.approx(0.0)
    assert extension_fraction_from_target_density(1.0 / 3.0) == pytest.approx(1.0)
    with pytest.raises(ValueError):
        extension_fraction_from_target_density(0.3)
