from __future__ import annotations

import numpy as np

from openvla.specdecoding.evidence.build_contextual_risk_evidence import (
    FEATURES,
    build_runtime_profile,
    chronological_mask,
    compute_risk_target,
    runtime_profile_filename,
    score_suite,
    selection_mask,
)


def _row(index: int, correction: float) -> dict:
    value = float(index) / 100.0
    row = {
        "task_suite_name": "libero_goal",
        "task_id": index % 10,
        "episode_seed": 1000 + index,
        "step": index,
        "correction_l2": correction,
        "gripper_switch": index % 17 == 0,
    }
    for feature in FEATURES:
        row[feature] = value
    return row


def test_equal_budget_masks_select_exact_rounded_count() -> None:
    rows = [_row(index, float(index)) for index in range(25)]
    expected = round(0.48 * len(rows))
    assert selection_mask(np.arange(len(rows)), 0.48).sum() == expected
    assert chronological_mask(rows, expected).sum() == expected


def test_context_scores_rank_monotonic_synthetic_correction() -> None:
    calibration = [_row(index * 2, index / 50.0) for index in range(64)]
    evaluation = [_row(index * 2 + 1, (index + 0.5) / 50.0) for index in range(32)]
    discrimination, allocation = score_suite(
        "libero_goal",
        calibration,
        evaluation,
        extension_fraction=0.5,
        unsafe_quantile=0.75,
    )
    scores = {row["method"]: row for row in discrimination}
    assert scores["visual"]["spearman"] > 0.99
    assert scores["context_energy"]["spearman"] > 0.99
    assert scores["local_quantile"]["spearman"] > 0.99
    selected = {row["method"]: row for row in allocation}
    assert selected["visual"]["selected_count"] == 16
    assert (
        selected["visual"]["mean_correction_l2"]
        < selected["chronological"]["mean_correction_l2"]
    )


def test_runtime_profile_is_self_contained() -> None:
    calibration = [_row(index, index / 50.0) for index in range(64)]
    profile = build_runtime_profile(
        suite="libero_goal",
        calibration_rows=calibration,
        calibration_seed=7,
        unsafe_quantile=0.75,
        lag=2,
    )
    assert profile["feature_names"] == [
        "image_relative_l2",
        "eef_position_l2",
        "eef_rotation_l2",
        "anchor_action_change_l2",
        "anchor_action_norm",
    ]
    assert len(profile["normalized_contexts"]) == len(calibration)
    assert len(profile["correction_l2"]) == len(calibration)
    assert len(profile["risk_reference"]) == len(calibration)
    assert profile["neighbors"] == 16


def test_runtime_profile_can_estimate_expected_target_correction() -> None:
    calibration = [_row(index, index / 50.0) for index in range(64)]
    profile = build_runtime_profile(
        suite="libero_goal",
        calibration_rows=calibration,
        calibration_seed=7,
        unsafe_quantile=0.75,
        lag=2,
        local_risk_statistic="mean",
        calibration_scope="leave_one_suite_out",
        source_task_suites=("libero_object", "libero_spatial"),
    )
    assert profile["local_risk_statistic"] == "mean"
    assert profile["local_risk_quantile"] is None
    assert profile["calibration_scope"] == "leave_one_suite_out"
    assert profile["source_task_suites"] == ["libero_object", "libero_spatial"]
    assert profile["profile_labels_shuffled"] is False


def test_shuffled_profile_name_takes_precedence_over_transfer_scope() -> None:
    assert runtime_profile_filename(
        "libero_goal",
        calibration_scope="leave_one_suite_out",
        labels_shuffled=True,
    ) == "context_risk_profile_shuffled_libero_goal.json"


def test_normalized_action_innovation_is_scale_aware_and_switch_sensitive() -> None:
    context_step = {"current_action_norm": 2.0}
    lag_record = {
        "anchor_action_norm": 2.0,
        "stale_action_correction_l2": 0.0,
        "inverse_age_action_correction_l2": 1.0,
        "gripper_switch": False,
    }
    assert compute_risk_target(
        context_step, lag_record, "normalized_action_innovation"
    ) == 0.0
    lag_record["stale_action_correction_l2"] = 2.0
    assert np.isclose(
        compute_risk_target(
            context_step, lag_record, "normalized_action_innovation"
        ),
        0.5,
    )
    lag_record["gripper_switch"] = True
    assert compute_risk_target(
        context_step, lag_record, "normalized_action_innovation"
    ) == 1.0
