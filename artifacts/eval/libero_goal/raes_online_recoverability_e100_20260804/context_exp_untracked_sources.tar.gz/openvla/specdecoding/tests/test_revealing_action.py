import unittest

import numpy as np

from openvla.specdecoding.model.revealing_action import (
    OnlineLocalRevealingRiskModel,
    OnlineRevealingAuthorityModel,
    OnlineRevealingResidualModel,
    OnlineRevealingRiskModel,
    OnlineTargetBudgetAllocator,
    OnlineTransitionObserver,
    OnlineVTPFUtilityModel,
    accumulate_recoverability_hazard,
    cost_aware_revealing_priority,
    evaluate_target_grounded_reuse,
    project_target_onto_anchor,
    select_monotone_risk_envelope,
)


class OnlineRevealingRiskModelTest(unittest.TestCase):
    def test_monotone_envelope_keeps_the_most_conservative_prefix_depth(self):
        model = OnlineRevealingRiskModel(("depth",), min_records=3)
        for depth, risk in ((1.0, 0.1), (2.0, 0.5), (3.0, 0.2)):
            model.observe({"depth": depth}, correction_l2=risk)
        estimates = [model.estimate({"depth": depth}) for depth in (1.0, 2.0, 3.0)]

        envelope_depth, envelope = select_monotone_risk_envelope(estimates)

        expected = max(estimates, key=lambda item: item.upper_confidence_risk)
        self.assertIs(envelope, expected)
        self.assertEqual(envelope_depth, estimates.index(expected) + 1)

    def test_learns_contextual_risk_order_without_offline_profile(self):
        model = OnlineRevealingRiskModel(
            ("visual_drift", "state_drift"), min_records=4
        )
        for visual in np.linspace(0.0, 1.0, 20):
            state = 0.5 * visual
            model.observe(
                {"visual_drift": visual, "state_drift": state},
                correction_l2=0.1 + 0.8 * visual + 0.2 * state,
            )

        safe = model.estimate({"visual_drift": 0.1, "state_drift": 0.05})
        risky = model.estimate({"visual_drift": 0.9, "state_drift": 0.45})
        self.assertTrue(safe.ready)
        self.assertGreater(risky.predicted_correction, safe.predicted_correction)
        self.assertGreaterEqual(risky.risk_percentile, safe.risk_percentile)

    def test_unknown_context_has_larger_epistemic_uncertainty(self):
        model = OnlineRevealingRiskModel(("x",), min_records=3)
        for value in np.linspace(0.0, 1.0, 12):
            model.observe({"x": value}, correction_l2=0.2 + 0.1 * value)
        familiar = model.estimate({"x": 0.5})
        novel = model.estimate({"x": 8.0})
        self.assertGreater(novel.epistemic_uncertainty, familiar.epistemic_uncertainty)

    def test_requires_revealed_records_before_holding(self):
        model = OnlineRevealingRiskModel(("x", "y"))
        empty = model.estimate({"x": 0.0, "y": 0.0})
        self.assertFalse(empty.ready)
        self.assertEqual(empty.risk_percentile, 1.0)


class OnlineLocalRevealingRiskModelTest(unittest.TestCase):
    def test_novel_context_receives_a_larger_local_confidence_bound(self):
        model = OnlineLocalRevealingRiskModel(("x", "depth"), min_records=4)
        for value in np.linspace(0.0, 1.0, 24):
            model.observe(
                {"x": float(value), "depth": 1.0},
                correction_l2=0.1 + 0.05 * float(value),
            )

        familiar = model.estimate({"x": 0.5, "depth": 1.0})
        novel_depth = model.estimate({"x": 0.5, "depth": 4.0})

        self.assertTrue(familiar.ready)
        self.assertGreater(
            novel_depth.epistemic_uncertainty,
            familiar.epistemic_uncertainty,
        )
        self.assertGreater(
            novel_depth.upper_confidence_risk,
            familiar.upper_confidence_risk,
        )

    def test_local_memory_preserves_nonlinear_safe_region(self):
        model = OnlineLocalRevealingRiskModel(("x",), min_records=4)
        for value in np.linspace(-2.0, 2.0, 41):
            model.observe(
                {"x": float(value)},
                correction_l2=float(value * value),
            )

        center = model.estimate({"x": 0.0})
        edge = model.estimate({"x": 1.8})
        self.assertLess(center.predicted_correction, edge.predicted_correction)
        self.assertLess(center.risk_percentile, edge.risk_percentile)


class OnlineVTPFUtilityModelTest(unittest.TestCase):
    def test_learns_that_stable_contexts_make_target_calls_cheaper(self):
        model = OnlineVTPFUtilityModel(("drift",), min_records=4)
        for drift in np.linspace(0.0, 1.0, 40):
            model.observe(
                {"drift": float(drift)},
                full_match=bool(drift < 0.35),
            )

        stable = model.estimate({"drift": 0.1})
        changing = model.estimate({"drift": 0.9})

        self.assertTrue(stable.ready)
        self.assertGreater(
            stable.full_match_probability,
            changing.full_match_probability,
        )
        self.assertLess(
            stable.expected_target_forwards,
            changing.expected_target_forwards,
        )

    def test_priority_favors_equal_risk_with_lower_expected_cost(self):
        model = OnlineVTPFUtilityModel(("drift",), min_records=4)
        for _ in range(12):
            model.observe({"drift": 0.0}, full_match=True)
            model.observe({"drift": 1.0}, full_match=False)

        cheap = model.estimate({"drift": 0.0})
        expensive = model.estimate({"drift": 1.0})

        self.assertGreater(
            cost_aware_revealing_priority(0.6, cheap),
            cost_aware_revealing_priority(0.6, expensive),
        )


class OnlineTransitionObserverTest(unittest.TestCase):
    def test_prequential_surprise_detects_an_unexpected_transition(self):
        observer = OnlineTransitionObserver(
            state_dimension=1,
            action_dimension=1,
            min_records=4,
        )
        state = np.asarray([0.0])
        for _ in range(30):
            action = np.asarray([0.1])
            observer.stage(state, action)
            state = state + action
            estimate = observer.observe(state)

        observer.stage(state, np.asarray([0.1]))
        expected = observer.observe(state + 0.1)
        observer.stage(state + 0.1, np.asarray([0.1]))
        unexpected = observer.observe(state + 1.2)

        self.assertTrue(expected.ready)
        self.assertTrue(unexpected.ready)
        self.assertGreater(unexpected.surprise, expected.surprise)
        self.assertGreaterEqual(
            unexpected.surprise_percentile,
            expected.surprise_percentile,
        )

    def test_episode_reset_drops_only_pending_transition(self):
        observer = OnlineTransitionObserver(
            state_dimension=1,
            action_dimension=1,
            min_records=2,
        )
        observer.stage([0.0], [0.1])
        observer.observe([0.1])
        observer.reset_episode()

        estimate = observer.observe([4.0])
        self.assertFalse(estimate.ready)
        self.assertEqual(observer.observed_transitions, 1)


class RecoverabilityHazardTest(unittest.TestCase):
    def test_hazard_accumulates_and_target_reset_is_well_defined(self):
        hazard_1, survival_1 = accumulate_recoverability_hazard(1.0, 0.2)
        hazard_2, survival_2 = accumulate_recoverability_hazard(survival_1, 0.3)

        self.assertAlmostEqual(hazard_1, 0.2)
        self.assertAlmostEqual(survival_1, 0.8)
        self.assertAlmostEqual(hazard_2, 0.44)
        self.assertAlmostEqual(survival_2, 0.56)


class OnlineTargetBudgetAllocatorTest(unittest.TestCase):
    def test_warmup_reveals_do_not_create_compensating_hold_debt(self):
        allocator = OnlineTargetBudgetAllocator(desired_target_density=0.4)
        initial_threshold = allocator.hold_threshold
        for _ in range(20):
            decision = allocator.decide(
                risk_percentile=1.0,
                eligible=True,
                model_ready=False,
            )
            self.assertFalse(decision.allow_hold)
            self.assertEqual(decision.step_size, 0.0)
        self.assertEqual(allocator.hold_threshold, initial_threshold)

    def test_forced_targets_and_contextual_holds_share_one_budget(self):
        allocator = OnlineTargetBudgetAllocator(desired_target_density=0.4)
        decisions = []
        consecutive_holds = 0
        for step in range(500):
            eligible = step > 6 and consecutive_holds < 2
            decision = allocator.decide(
                risk_percentile=(step % 17) / 16.0,
                eligible=eligible,
                model_ready=step > 6,
            )
            decisions.append(decision)
            consecutive_holds = consecutive_holds + 1 if decision.allow_hold else 0

        realized_target_density = allocator.target_count / allocator.decision_count
        self.assertAlmostEqual(realized_target_density, 0.4, delta=0.04)
        self.assertTrue(any(item.reason == "target_required" for item in decisions))
        self.assertTrue(any(item.reason == "contextual_hold" for item in decisions))


class OnlineRevealingResidualModelTest(unittest.TestCase):
    def test_prequential_evidence_grants_useful_residual_authority(self):
        model = OnlineRevealingResidualModel(
            ("x",), action_dimension=2, min_records=3
        )
        for value in np.linspace(-1.0, 1.0, 30):
            features = {"x": float(value)}
            estimate = model.estimate(features)
            residual = np.asarray((0.4 * value, -0.2 * value + 0.1))
            model.observe(
                features,
                residual,
                prequential_prediction=estimate.predicted_residual,
                prequential_ready=estimate.ready,
            )

        query = model.estimate({"x": 0.75})
        self.assertTrue(query.ready)
        self.assertGreater(query.learned_authority, 0.8)
        self.assertGreater(model.prequential_improvement, 0.5)
        np.testing.assert_allclose(
            query.predicted_residual, (0.3, -0.05), atol=0.03
        )

    def test_authority_stays_zero_before_out_of_sample_evidence(self):
        model = OnlineRevealingResidualModel(
            ("x",), action_dimension=2, min_records=3
        )
        for value in (-1.0, 0.0, 1.0):
            model.observe({"x": value}, (value, -value))
        estimate = model.estimate({"x": 0.5})
        self.assertTrue(estimate.ready)
        self.assertEqual(estimate.learned_authority, 0.0)


class OnlineRevealingAuthorityModelTest(unittest.TestCase):
    def test_fit_is_not_deployed_before_prequential_improvement(self):
        model = OnlineRevealingAuthorityModel(("depth",), min_records=3)
        for depth in (1.0, 2.0, 3.0):
            model.observe({"depth": depth}, 0.8)

        estimate = model.estimate({"depth": 2.0})
        self.assertTrue(estimate.ready)
        self.assertFalse(estimate.certified)

    def test_learns_context_dependent_bounded_authority(self):
        model = OnlineRevealingAuthorityModel(("depth", "drift"), min_records=4)
        for drift in np.linspace(0.0, 1.0, 30):
            features = {"depth": 2.0, "drift": float(drift)}
            estimate = model.estimate(features)
            target = 1.0 - 0.5 * drift
            model.observe(
                features,
                target,
                prequential_prediction=estimate.predicted_authority,
                prequential_ready=estimate.ready,
                baseline_squared_error=1.0 if estimate.ready else None,
                predicted_squared_error=0.25 if estimate.ready else None,
            )
        low_drift = model.estimate({"depth": 2.0, "drift": 0.1})
        high_drift = model.estimate({"depth": 2.0, "drift": 0.9})
        self.assertTrue(low_drift.ready)
        self.assertTrue(low_drift.certified)
        self.assertGreater(low_drift.predicted_authority, high_drift.predicted_authority)
        self.assertAlmostEqual(model.prequential_improvement, 0.75)


class TargetGroundedProjectionTest(unittest.TestCase):
    def test_separates_scalable_motion_from_irreducible_innovation(self):
        anchor = np.asarray([1.0, 2.0, 0.0, 0.0, 0.0, 0.0, -1.0])
        target = np.asarray([0.5, 1.0, 0.0, 0.0, 0.0, 0.0, -1.0])
        projection = project_target_onto_anchor(anchor, target, np.ones(7))
        self.assertAlmostEqual(projection.optimal_authority, 0.5)
        self.assertAlmostEqual(projection.innovation_l2, 0.0)

        gripper_flip = target.copy()
        gripper_flip[6] = 1.0
        projection = project_target_onto_anchor(anchor, gripper_flip, np.ones(7))
        self.assertAlmostEqual(projection.optimal_authority, 0.5)
        self.assertAlmostEqual(projection.innovation_l2, 2.0)

    def test_reuse_error_scores_deployed_authority_and_gripper(self):
        anchor = [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0]
        target = [0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        scale = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0]

        accurate = evaluate_target_grounded_reuse(
            anchor, target, scale, authority=0.5
        )
        stale = evaluate_target_grounded_reuse(
            anchor, target, scale, authority=1.0
        )

        self.assertEqual(accurate.authority, 0.5)
        self.assertEqual(accurate.normalized_error[-1], 1.0)
        self.assertEqual(accurate.error_l2, 1.0)
        self.assertGreater(stale.error_l2, accurate.error_l2)


if __name__ == "__main__":
    unittest.main()
